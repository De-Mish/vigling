<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Access\Access;

$user = Factory::getApplication()->getIdentity();
$isOwn = $user->id == $this->data->id;
$userGroups = $user->id ? $user->getAuthorisedGroups() : [];
$isMaster = in_array(3, $userGroups) || in_array(8, $userGroups);
$profileOwnerId = (int) ($this->data->id ?? 0);
$profileGroups = $profileOwnerId > 0 ? Access::getGroupsByUser($profileOwnerId, false) : [];
$profileIsMaster = in_array(3, $profileGroups) || in_array(8, $profileGroups);
$roleLabel = $profileIsMaster ? 'Мастер' : 'Клиент';
$avatarUrl = '';
$portfolioField = null;
$specialityText = Text::_('COM_USERS_PROFILE_VALUE_NOT_FOUND');
$pricesRaw = '';
$stockPricesRaw = '';
$avatarRaw = '';
if (!empty($this->data->jcfields)) {
	foreach ($this->data->jcfields as $f) {
		if (!isset($f->name)) continue;
		if ($f->name === 'avatar') {
			$v = isset($f->rawvalue) ? $f->rawvalue : (isset($f->value) ? $f->value : '');
			$avatarRaw = is_string($v) ? trim($v) : '';
		}
		if ($f->name === 'portfolio_field') {
			$portfolioField = $f;
		}
		if ($f->name === 'vyberite_spetsialnos' && !empty($f->value)) {
			$specialityText = $f->value;
		}
		if ($f->name === 'prices' && isset($f->rawvalue)) {
			$pricesRaw = is_string($f->rawvalue) ? $f->rawvalue : '';
		}
		if ($f->name === 'stock_prices' && isset($f->rawvalue)) {
			$stockPricesRaw = is_string($f->rawvalue) ? $f->rawvalue : '';
		}
	}
}
if (empty($this->data->jcfields) && !empty($this->data->id)) {
	$fields = \Joomla\Component\Fields\Administrator\Helper\FieldsHelper::getFields('com_users.user', $this->data, true);
	foreach ($fields as $f) {
		if (!isset($f->name)) continue;
		if ($f->name === 'prices' && isset($f->rawvalue)) {
			$pricesRaw = is_string($f->rawvalue) ? $f->rawvalue : '';
		}
		if ($f->name === 'stock_prices' && isset($f->rawvalue)) {
			$stockPricesRaw = is_string($f->rawvalue) ? $f->rawvalue : '';
		}
	}
}
$pricesStructured = [];
$stockPricesStructured = [];
$pricesStructuredWithIds = [];
$stockPricesStructuredWithIds = [];
if ($pricesRaw !== '') {
	$pricesStructured = \Joomla\Plugin\User\Vigling\Helper\JsnDecodeHelper::getPricesStructured($pricesRaw);
	$pricesStructuredWithIds = \Joomla\Plugin\User\Vigling\Helper\JsnDecodeHelper::getPricesStructuredWithIds($pricesRaw);
}
if ($stockPricesRaw !== '') {
	$stockPricesStructured = \Joomla\Plugin\User\Vigling\Helper\JsnDecodeHelper::getPricesStructured($stockPricesRaw);
	$stockPricesStructuredWithIds = \Joomla\Plugin\User\Vigling\Helper\JsnDecodeHelper::getPricesStructuredWithIds($stockPricesRaw);
}
if ($avatarRaw === '' && !empty($this->data->id)) {
	$fields = \Joomla\Component\Fields\Administrator\Helper\FieldsHelper::getFields('com_users.user', $this->data, true);
	foreach ($fields as $f) {
		if (isset($f->name) && $f->name === 'avatar') {
			$v = isset($f->rawvalue) ? $f->rawvalue : (isset($f->value) ? $f->value : '');
			$avatarRaw = is_string($v) ? trim($v) : '';
			break;
		}
	}
}
if ($avatarRaw !== '') {
	$dec = json_decode($avatarRaw, true);
	$avatarUrl = is_string($dec) ? $dec : (is_array($dec) ? (string) reset($dec) : $avatarRaw);
	$avatarUrl = trim((string) $avatarUrl);
	if ($avatarUrl !== '' && strpos($avatarUrl, 'http') !== 0) {
		$avatarUrl = preg_replace('#^/?(images/profiler/?)?#i', '', str_replace('\\', '/', $avatarUrl));
		$avatarUrl = rtrim(Uri::root(), '/') . '/images/profiler/' . $avatarUrl;
	}
}

// Получить услуги из #__content (статьи мастера по категориям из field_id=29)
$masterServicesFromContent = [];
if ($profileIsMaster && !empty($profileOwnerId)) {
	try {
		$db = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);
		$prefix = $db->getPrefix();

		// Получить специальности мастера (field_id=29)
		$specQuery = $db->getQuery(true)
			->select('DISTINCT value')
			->from($db->quoteName($prefix . 'fields_values'))
			->where('field_id = 29')
			->where('item_id = ' . $profileOwnerId);
		$db->setQuery($specQuery);
		$specValues = $db->loadColumn();

		if (!empty($specValues)) {
			$specIds = [];
			foreach ($specValues as $v) {
				$ids = array_filter(array_map('intval', explode(',', $v)));
				$specIds = array_merge($specIds, $ids);
			}

			if (!empty($specIds)) {
				// Получить категории специальностей
				$catQuery = $db->getQuery(true)
					->select(['id', 'title'])
					->from($db->quoteName($prefix . 'categories'))
					->where('id IN (' . implode(',', $specIds) . ')')
					->where('published = 1')
					->order('title ASC');
				$db->setQuery($catQuery);
				$categories = $db->loadAssocList();

				foreach ($categories as $cat) {
					$catId = (int)$cat['id'];
					// Получить услуги в этой категории и её дочерних
					$svcQuery = $db->getQuery(true)
						->select(['c.id', 'c.title', 'c.catid', 'c.state', 'cat.title as subcategory_title'])
						->from($db->quoteName($prefix . 'content', 'c'))
						->innerJoin($db->quoteName($prefix . 'categories', 'cat') . ' ON c.catid = cat.id')
						->where('cat.parent_id = ' . $catId)
						->where('c.created_by = ' . $profileOwnerId)
						->where('c.state IN (0, 1)')
						->order('c.title ASC');
					$db->setQuery($svcQuery);
					$services = $db->loadAssocList();

					if (!empty($services)) {
						// Загрузить доп. поля для каждой услуги
						foreach ($services as &$svc) {
							$fieldsQuery = $db->getQuery(true)
								->select(['field_id', 'value'])
								->from($db->quoteName($prefix . 'fields_values'))
								->where('item_id = ' . (int)$svc['id'])
								->where('field_id IN (56, 63, 64, 66, 67, 68, 69, 70)');
							$db->setQuery($fieldsQuery);
							$fields = $db->loadAssocList('field_id');
							$svc['fields'] = $fields;
						}

						$masterServicesFromContent[] = [
							'category_id' => $catId,
							'category_title' => $cat['title'],
							'services' => $services
						];
					}
				}
			}
		}
	} catch (Exception $e) {
		// Игнорировать ошибки БД
	}
}

$masterServicesList = [];
if (!$isOwn && $pricesRaw !== '') {
	$normalized = preg_replace('/(\d+)\s*:/', '"$1":', $pricesRaw);
	$data = is_string($normalized) ? json_decode($normalized, true) : null;
	if (is_array($data)) {
		$svcIds = [];
		foreach ($data as $items) {
			if (!is_array($items)) continue;
			foreach ($items as $triple) {
				if (is_array($triple) && count($triple) >= 3) {
					$svcIds[(string) $triple[2]] = true;
				}
			}
		}
		if (!empty($svcIds)) {
			$db = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);
			$ids = [];
			foreach (array_keys($svcIds) as $k) {
				$id = strpos($k, '-') !== false ? (int) explode('-', $k)[0] : (int) $k;
				if ($id > 0) $ids[] = $id;
			}
			$ids = array_unique($ids);
			if (!empty($ids)) {
				$query = $db->getQuery(true)
					->select($db->quoteName('id') . ',' . $db->quoteName('title'))
					->from($db->quoteName('#__content'))
					->where($db->quoteName('id') . ' IN (' . implode(',', $ids) . ')');
				$db->setQuery($query);
				$rows = $db->loadAssocList() ?: [];
				foreach ($rows as $r) {
					$masterServicesList[(string) $r['id']] = $r['title'];
				}
			}
			foreach (array_keys($svcIds) as $id) {
				$key = (string) (strpos($id, '-') !== false ? explode('-', $id)[0] : $id);
				if (!isset($masterServicesList[$key])) {
					$masterServicesList[$key] = 'Услуга #' . $key;
				}
			}
		}
	}
}
$displayName = isset($this->data->name) && (string) $this->data->name !== '' ? $this->data->name : $this->data->username;
$pushnotifyBase = Route::_('index.php?option=com_pushnotify');
$pushnotifySwUrl = rtrim(Uri::root(), '/') . '/firebase-messaging-sw.js';
$pushnotifyTokenName = Session::getFormToken();
$pushnotifyTokenValue = '1';
$pushnotifyRoot = rtrim(Uri::root(), '/');
$defaultImg = Uri::root() . 'templates/ryba/images/master.png';
if (!is_file(JPATH_ROOT . '/templates/ryba/images/master.png')) {
	$defaultImg = Uri::root() . 'components/com_jsn/assets/img/default.jpg';
}
?>
<style>
.lk-notify-btn { position: relative; }
.lk-notify-badge { position: absolute; top: -4px; right: -4px; min-width: 16px; height: 16px; line-height: 16px; padding: 0 4px; font-size: 11px; text-align: center; background: #c00; color: #fff; border-radius: 8px; }
.lk-notify-item-read { color: #777; }
</style>
<div id="easyprofile" class="view_profile">
	<div class="jsn-p">
		<div class="view_profile-header">
			<div class="jsn-p-top jsn-p-top-a">
				<div class="jsn-p-avatar">
					<?php if ($avatarUrl) : ?>
						<img src="<?php echo $this->escape($avatarUrl); ?>" alt="<?php echo $this->escape($displayName); ?>" class="avatar">
					<?php else : ?>
						<div class="avatar avatar-placeholder"><?php echo $this->escape(mb_substr($displayName, 0, 1)); ?></div>
					<?php endif; ?>
					<span class="avatar-online" title="OnLine" aria-hidden="true"></span>
				</div>
				<div class="jsn-p-title">
					<h3><?php echo $this->escape($displayName); ?></h3>
					<span class="jsn-p-role"><?php echo $this->escape($roleLabel); ?></span>
				</div>
				<div class="jsn-p-before-fields"></div>
			</div>
			<div class="jsn-p-opt">
				<?php if ($isOwn) : ?>
					<a class="btn btn-xs btn-default" href="<?php echo Route::_('index.php?option=com_users&task=profile.edit&user_id=' . (int) $this->data->id); ?>">
						<i class="jsn-icon jsn-icon-cog"></i> Параметры профиля</a>
					<?php
					$ordersComp = ComponentHelper::getComponent('com_orders');
					$ordersItem = $ordersComp->id ? Factory::getApplication()->getMenu()->getItems(['component_id'], [$ordersComp->id], true) : null;
					$ordersUrl = $ordersItem ? Route::_('index.php?Itemid=' . (int) $ordersItem->id) : Route::_('index.php?option=com_orders&view=orders');
					$clientsUrl = $ordersItem ? Route::_('index.php?option=com_orders&view=orders&layout=clients&Itemid=' . (int) $ordersItem->id) : Route::_('index.php?option=com_orders&view=orders&layout=clients');
					?>
					<div class="lk-notify-wrap" style="display:inline-block; position:relative; vertical-align:middle;">
						<button type="button" class="btn btn-xs btn-default lk-notify-btn" id="lk-notify-toggle" aria-expanded="false" aria-haspopup="true" title="Уведомления">
							<i class="fa fa-bell" aria-hidden="true"></i>
							<span class="lk-notify-badge" id="lk-notify-badge" style="display:none;">0</span>
						</button>
						<div class="lk-notify-dropdown" id="lk-notify-dropdown" style="display:none; position:absolute; top:100%; right:0; margin-top:4px; min-width:320px; max-width:400px; max-height:70vh; overflow:auto; background:#fff; border:1px solid #ddd; border-radius:4px; box-shadow:0 4px 12px rgba(0,0,0,0.15); z-index:1000;">
							<div class="lk-notify-header" style="padding:8px 12px; border-bottom:1px solid #eee; font-weight:bold;">Уведомления</div>
							<div class="lk-notify-list" id="lk-notify-list"></div>
							<div class="lk-notify-empty" id="lk-notify-empty" style="display:none; padding:16px; color:#888;">Нет уведомлений</div>
							<div class="lk-notify-loading" id="lk-notify-loading" style="display:none; padding:16px; text-align:center;">Загрузка…</div>
						</div>
					</div>
					<a class="btn btn-xs btn-default" href="<?php echo $ordersUrl; ?>">
						<i class="jsn-icon jsn-icon-cog"></i> Мои записи</a>
					<?php if ($isMaster) : ?>
					<a class="btn btn-xs btn-default" href="<?php echo $clientsUrl; ?>">
						<i class="jsn-icon jsn-icon-user"></i> Мои клиенты</a>
					<?php endif; ?>
				<?php else : ?>
					<button type="button" class="btn btn-xs btn-primary" id="lk-booking-toggle" aria-expanded="false">
						Записаться
					</button>
				<?php endif; ?>
			</div>
		</div>
		<?php if (!$isOwn && (int) $this->data->id > 0) : ?>
		<div id="lk-booking-block" class="view_profile-booking" style="display:none;">
			<form id="lk-booking-form" class="form-horizontal">
				<div class="form-group">
					<label class="control-label">Дата и время начала записи</label>
					<div class="controls lk-booking-datetime">
						<input type="date" name="booking_date" id="lk-booking-date" required class="form-control">
						<input type="time" name="booking_time" id="lk-booking-time" required class="form-control lk-booking-time-start">
					</div>
				</div>
				<?php if (!empty($masterServicesList)) : ?>
				<div class="form-group">
					<label class="control-label">Услуга</label>
					<div class="controls">
						<select name="service_id" id="lk-booking-service" class="form-control" required>
							<option value="">— выбрать —</option>
							<?php foreach ($masterServicesList as $sid => $title) : ?>
								<option value="<?php echo $this->escape($sid); ?>" data-name="<?php echo $this->escape($title); ?>"><?php echo $this->escape($title); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>
				<?php else : ?>
				<div class="form-group">
					<label class="control-label">Услуга</label>
					<div class="controls">
						<input type="text" name="service_name" id="lk-booking-service-name" class="form-control" placeholder="Название услуги" required>
					</div>
				</div>
				<?php endif; ?>
				<div class="form-group">
					<label class="control-label">Комментарий</label>
					<div class="controls">
						<textarea name="note" id="lk-booking-note" class="form-control" rows="2" placeholder="Необязательно"></textarea>
					</div>
				</div>
				<div class="form-group">
					<div class="controls">
						<button type="submit" class="btn btn-primary" id="lk-booking-submit">Отправить запись</button>
						<span id="lk-booking-msg" class="lk-booking-msg"></span>
					</div>
				</div>
				<input type="hidden" name="master_id" value="<?php echo (int) $this->data->id; ?>">
				<input type="hidden" name="duration_min" value="60">
				<input type="hidden" name="time" id="lk-booking-time-combined" value="">
				<input type="hidden" name="service_name" id="lk-booking-service-name-hidden" value="">
				<input type="hidden" name="<?php echo $this->escape($pushnotifyTokenName); ?>" value="<?php echo $this->escape($pushnotifyTokenName); ?>">
			</form>
		</div>
		<?php endif; ?>
		<form class="jsn-p-fields">
			<div id="jsn-form" class="hover clean mini flat z-icons-light z-shadows z-spaced z-tabs horizontal top-compact top view_profile-tabs">
				<ul class="z-tabs-nav z-tabs-mobile" style="display: none;"><li><a class="z-link" style="text-align: left;"><span class="z-title">Профиль</span><span class="z-arrow"></span></a></li></ul>
				<i class="z-dropdown-arrow"></i>
				<ul id="jsn-profile-tabs" class="z-tabs-nav z-tabs-desktop">
					<li data-index="0" data-link="profile-tab0" class="z-tab z-first z-active" style="width: 14.28%;"><a class="z-link" style="min-height: 18px;">Профиль<span></span></a></li>
					<li data-index="1" data-link="profile-tab1" class="z-tab" style="width: 14.28%;"><a class="z-link" style="min-height: 18px;">Портфолио<span></span></a></li>
					<li data-index="2" data-link="profile-tab2" class="z-tab" style="width: 14.28%;"><a class="z-link" style="min-height: 18px;">Специальность<span></span></a></li>
					<li data-index="3" data-link="profile-tab3" class="z-tab" style="width: 14.28%;"><a class="z-link" style="min-height: 18px;">Услуги и цены<span></span></a></li>
					<li data-index="4" data-link="profile-tab4" class="z-tab" style="width: 14.28%;"><a class="z-link" style="min-height: 18px;">Акции<span></span></a></li>
					<li data-index="5" data-link="profile-tab5" class="z-tab" style="width: 14.28%;"><a class="z-link" style="min-height: 18px;">Уведомления<span></span></a></li>
					<li data-index="6" data-link="profile-tab6" class="z-tab z-last" style="width: 14.28%;"><a class="z-link" style="min-height: 18px;">Логин и пароль<span></span></a></li>
				</ul>
				<div class="z-container">
					<div class="z-content z-active" data-index="0" data-name="profile-tab0">
						<div class="z-content-inner">
							<fieldset id="jsn_default" class="jsn-form-fieldset" data-index="0" data-name="profile-tab0">
								<legend style="display: none;">Профиль</legend>
								<?php echo $this->loadTemplate('profile_main'); ?>
								<?php echo $this->loadTemplate('core'); ?>
								<?php echo $this->loadTemplate('params'); ?>
								<?php echo $this->loadTemplate('custom'); ?>
								<?php if ($pricesStructuredWithIds !== [] || $stockPricesStructuredWithIds !== []) : ?>
								<div class="view_profile-services">
									<?php if ($pricesStructuredWithIds !== []) : ?>
									<div class="profile-services-block">
										<h4 class="profile-services-title">Услуги и цены</h4>
										<?php
										$accClass = 'opened';
										$accCounter = 0;
										foreach ($pricesStructuredWithIds as $cat) :
											$accCounter++;
										?>
										<div class="accordionItem <?php echo $accClass; ?>">
											<h2 class="accordionItemHeading accordionItemHeading<?php echo $accCounter; ?>"><?php echo $this->escape($cat['title']); ?></h2>
											<div class="accordionItemContent accordionItemContent<?php echo $accCounter; ?>"><div class="priceList">
												<?php foreach ($cat['items'] as $item) : ?>
												<div class="priceList__item" data-svc-id="<?php echo $this->escape($item['svc_id']); ?>" data-tag-id="<?php echo (int) $item['tag_id']; ?>">
													<div class="priceList__item-coll price__coll1"><?php echo $this->escape($cat['title']); ?> — <?php echo $this->escape($item['name']); ?></div>
													<div class="priceList__item-coll price__coll2">от <?php echo (int) $item['price']; ?> <span class="price_span">руб.</span></div>
													<div class="priceList__item-coll price__coll3"><?php echo (int) $item['duration']; ?> мин</div>
													<?php if (!$isOwn && (int) $this->data->id > 0) : ?>
													<button type="button" class="btn_add-master plus" data-srv-time="<?php echo (int) $item['duration']; ?>" data-toggle="booking" aria-label="Записаться"></button>
													<?php endif; ?>
													<div class="clearFloat"></div>
												</div>
												<?php endforeach; ?>
											</div></div>
										</div>
										<?php $accClass = 'closed'; endforeach; ?>
									</div>
									<?php endif; ?>
									<?php if ($stockPricesStructuredWithIds !== []) : ?>
									<div class="profile-services-block profile-services-block--stocks">
										<h4 class="profile-services-title">Акции</h4>
										<?php
										$accClass = 'opened';
										$accCounter = 0;
										foreach ($stockPricesStructuredWithIds as $cat) :
											$accCounter++;
										?>
										<div class="accordionItem <?php echo $accClass; ?>">
											<h2 class="accordionItemHeading accordionItemHeading<?php echo $accCounter; ?>"><?php echo $this->escape($cat['title']); ?></h2>
											<div class="accordionItemContent accordionItemContent<?php echo $accCounter; ?>"><div class="priceList">
												<?php foreach ($cat['items'] as $item) : ?>
												<div class="priceList__item priceList__item--stock" data-svc-id="<?php echo $this->escape($item['svc_id']); ?>" data-tag-id="<?php echo (int) $item['tag_id']; ?>">
													<div class="priceList__item-coll price__coll1"><?php echo $this->escape($cat['title']); ?> — <?php echo $this->escape($item['name']); ?></div>
													<div class="priceList__item-coll price__coll2">от <?php echo (int) $item['price']; ?> <span class="price_span">руб.</span></div>
													<div class="priceList__item-coll price__coll3"><?php echo (int) $item['duration']; ?> мин</div>
													<?php if (!$isOwn && (int) $this->data->id > 0) : ?>
													<button type="button" class="btn_add-master plus" data-srv-time="<?php echo (int) $item['duration']; ?>" data-toggle="booking" aria-label="Записаться"></button>
													<?php endif; ?>
													<div class="clearFloat"></div>
												</div>
												<?php endforeach; ?>
											</div></div>
										</div>
										<?php $accClass = 'closed'; endforeach; ?>
									</div>
									<?php endif; ?>
								</div>
								<script>
								(function(){
									var wrap = document.querySelector('.view_profile-services');
									if (!wrap) return;
									wrap.querySelectorAll('.accordionItemHeading').forEach(function(h){
										h.addEventListener('click', function(){
											var item = this.closest('.accordionItem');
											if (!item) return;
											item.classList.toggle('opened');
											item.classList.toggle('closed');
										});
									});
									wrap.querySelectorAll('.btn_add-master[data-toggle="booking"]').forEach(function(btn){
										btn.addEventListener('click', function(){
											var block = document.getElementById('lk-booking-block');
											var toggle = document.getElementById('lk-booking-toggle');
											if (block && toggle) { block.style.display = 'block'; toggle.setAttribute('aria-expanded', 'true'); }
										});
									});
								})();
								</script>
								<?php endif; ?>
								<!-- Услуги из #__content (статьи мастера) -->
								<?php if (!empty($masterServicesFromContent)) : ?>
								<div class="view_profile-services view_profile-services--content">
									<div class="profile-services-block">
										<h4 class="profile-services-title">Услуги</h4>
										<?php foreach ($masterServicesFromContent as $group) : ?>
										<div class="accordionItem opened">
											<h2 class="accordionItemHeading"><?php echo $this->escape($group['category_title']); ?></h2>
											<div class="accordionItemContent"><div class="priceList">
												<?php foreach ($group['services'] as $svc) :
													$duration = isset($svc['fields'][66]) ? $svc['fields'][66]['value'] : '';
													$cost = isset($svc['fields'][70]) ? $svc['fields'][70]['value'] : '';
													$costType = isset($svc['fields'][64]) ? $svc['fields'][64]['value'] : '';
													$prefix_str = ($costType == '2') ? 'от ' : '';
												?>
												<div class="priceList__item" data-svc-id="<?php echo (int)$svc['id']; ?>">
													<div class="priceList__item-coll price__coll1">
														<?php echo $this->escape($svc['title']); ?>
														<?php if ((int)$svc['state'] === 0) : ?>
														<span class="badge badge-warning" title="На модерации">модер.</span>
														<?php endif; ?>
													</div>
													<?php if (!empty($cost)) : ?>
													<div class="priceList__item-coll price__coll2"><?php echo $prefix_str . htmlspecialchars($cost); ?> <span class="price_span">руб.</span></div>
													<?php endif; ?>
													<?php if (!empty($duration)) : ?>
													<div class="priceList__item-coll price__coll3"><?php echo htmlspecialchars($duration); ?> мин</div>
													<?php endif; ?>
													<?php if ($isOwn) : ?>
													<div class="priceList__item-actions">
														<a href="<?php echo Route::_('index.php?option=com_content&task=article.edit&id=' . (int)$svc['id']); ?>"
														   class="btn btn-xs btn-outline-primary" title="Редактировать">
															<i class="fa fa-pencil"></i>
														</a>
														<button type="button" class="btn btn-xs btn-outline-danger delete-service-btn"
															data-id="<?php echo (int)$svc['id']; ?>"
															data-title="<?php echo $this->escape($svc['title']); ?>"
															title="Удалить">
															<i class="fa fa-trash"></i>
														</button>
													</div>
													<?php endif; ?>
													<div class="clearFloat"></div>
												</div>
												<?php endforeach; ?>
											</div></div>
										</div>
										<?php endforeach; ?>
									</div>
								</div>
								<script>
								(function(){
									var wrap = document.querySelector('.view_profile-services--content');
									if (!wrap) return;
									wrap.querySelectorAll('.accordionItemHeading').forEach(function(h){
										h.addEventListener('click', function(){
											var item = this.closest('.accordionItem');
											if (!item) return;
											item.classList.toggle('opened');
											item.classList.toggle('closed');
										});
									});
									wrap.querySelectorAll('.delete-service-btn').forEach(function(btn){
										btn.addEventListener('click', function(){
											var id = this.getAttribute('data-id');
											var title = this.getAttribute('data-title');
											if (confirm('Удалить услугу "' + title + '"?')) {
												// Отправить запрос на удаление
												fetch('<?php echo Route::_('index.php?option=com_content&task=article.delete', false); ?>', {
													method: 'POST',
													headers: {
														'Content-Type': 'application/x-www-form-urlencoded'
													},
													body: 'id=' + id + '&<?php echo Session::getFormToken(); ?>=1'
												}).then(function() {
													window.location.reload();
												});
											}
										});
									});
								})();
								</script>
								<?php endif; ?>
							</fieldset>
						</div>
					</div>
					<div class="z-content" data-index="1" data-name="profile-tab1" style="display: none;">
						<div class="z-content-inner">
							<fieldset id="jsn_portfolio" class="jsn-form-fieldset" data-index="1" data-name="profile-tab1">
								<legend style="display: none;">Портфолио</legend>
								<dl class="dl-horizontal">
									<dt class="no-title">Портфолио</dt>
									<dd class="portfolio_fieldValue"><div class="portfolio_field-group"></div></dd>
								</dl>
							</fieldset>
						</div>
					</div>
					<div class="z-content" data-index="2" data-name="profile-tab2" style="display: none;">
						<div class="z-content-inner">
							<fieldset id="jsn_spetsialnost" class="jsn-form-fieldset" data-index="2" data-name="profile-tab2">
								<legend style="display: none;">Специальность</legend>
								<dl class="dl-horizontal">
									<dt class="no-title">Выберите специальность</dt>
									<dd class="vyberite_spetsialnosValue"><?php echo $this->escape($specialityText); ?></dd>
								</dl>
							</fieldset>
						</div>
					</div>
					<div class="z-content" data-index="3" data-name="profile-tab3" style="display: none;">
						<div class="z-content-inner">
							<fieldset id="jsn_addinfo" class="jsn-form-fieldset" data-index="3" data-name="profile-tab3">
								<legend style="display: none;">Услуги и цены</legend>
								<dl class="dl-horizontal">
									<dt class="no-title">Цены</dt>
									<dd class="pricesValue"><fieldset id="jform_vyberite_usl" class="readonly">Выберите специальность, чтобы добавить услугу</fieldset></dd>
								</dl>
							</fieldset>
						</div>
					</div>
					<div class="z-content" data-index="4" data-name="profile-tab4" style="display: none;">
						<div class="z-content-inner">
							<fieldset id="jsn_stocks" class="jsn-form-fieldset" data-index="4" data-name="profile-tab4">
								<legend style="display: none;">Акции</legend>
								<dl class="dl-horizontal">
									<dt class="no-title">Акционные цены</dt>
									<dd class="stock_pricesValue"><fieldset id="jform_stocks_servis" class="readonly">Выберите специальность, чтобы акционную добавить услугу</fieldset></dd>
								</dl>
							</fieldset>
						</div>
					</div>
					<div class="z-content" data-index="5" data-name="profile-tab5" style="display: none;">
						<div class="z-content-inner">
							<fieldset id="jsn_notify" class="jsn-form-fieldset" data-index="5" data-name="profile-tab5">
								<legend style="display: none;">Уведомления</legend>
								<dl class="dl-horizontal">
									<dt class="no-title">Push-уведомления</dt>
									<dd>
										<?php if ($isOwn) : ?>
										<div class="push-notify-block">
											<div class="push-notify-row push-notify-row-status">
												<span id="pushnotify-status">—</span>
												<button type="button" id="pushnotify-subscribe-btn" class="btn btn-xs btn-primary">Включить уведомления</button>
												<button type="button" id="pushnotify-refresh-btn" class="btn btn-xs btn-default" style="display:none;">Обновить подписку на уведомления</button>
											</div>
											<div class="push-notify-row" id="pushnotify-toggle-wrap" style="display:none;">
												<label><input type="checkbox" id="pushnotify-enabled" /> Уведомления о записях</label>
												<button type="button" id="pushnotify-test-btn" class="btn btn-xs btn-success">Тест: отправить уведомление</button>
											</div>
										</div>
										<?php else : ?>
										<span>—</span>
										<?php endif; ?>
									</dd>
								</dl>
							</fieldset>
						</div>
					</div>
					<div class="z-content" data-index="6" data-name="profile-tab6" style="display: none;">
						<div class="z-content-inner">
							<fieldset id="jsn_login" class="jsn-form-fieldset" data-index="6" data-name="profile-tab6">
								<legend style="display: none;">Логин и пароль</legend>
								<dl class="dl-horizontal">
									<dt class="usernameLabel">Логин</dt>
									<dd class="usernameValue"><?php echo $this->escape(isset($this->data->username) ? $this->data->username : ''); ?></dd>
								</dl>
							</fieldset>
						</div>
					</div>
				</div>
			</div>
		</form>
		<div class="jsn-p-bottom">
			<div class="jsn-p-after-fields"></div>
		</div>
		<div style="display:none;" id="del-images">
			<div>
				<h3>Вы действительно желаете удалить</h3>
				<div class="del-img">
					<img src="/" alt="">
				</div>
				<div class="del-but d-flex jsn-p">
					<input type="button" class="btn btn-xs btn-default goDel" value="Да" data-url="">
					<input type="button" class="btn btn-xs btn-default" value="Нет" onclick="jQuery.fancybox.close();">
				</div>
			</div>
		</div>
	</div>
	<div class="masters__big-img-cont col-md-6">
		<div class="arrows_master-slider">
			<button type="button" class="my-slick-prev slick-arrow"><i class="fa fa-angle-left" aria-hidden="true"></i></button>
			<button type="button" class="my-slick-next slick-arrow"><i class="fa fa-angle-right" aria-hidden="true"></i></button>
		</div>
		<div class="masters__big-img">
			<div style="background-image: url('<?php echo $avatarUrl ? $this->escape($avatarUrl) : $defaultImg; ?>'); width: 100%; display: inline-block;" class="masters__big-img-item"></div>
		</div>
	</div>
	<div class="masters__big-info col-md-6">
		<div class="masters__big-info-head">
			<div class="masters__big-info-head-master" style="background-image: url('<?php echo $avatarUrl ? $this->escape($avatarUrl) : $defaultImg; ?>'); background-size: cover;">
				<span class="masters__big-info-head-master-online"></span>
			</div>
			<h3 class="h3biginfo"><?php echo $this->escape($displayName); ?></h3>
			<a id="bookmarkme" href="#" data-id="<?php echo (int) $this->data->id; ?>" title="Добавить в избранное"></a>
			<div class="clearFloat"></div>
		</div>
		<div class="masters__big-info-attr">
			<h3 class="h3biginfo1"><?php echo $this->escape($displayName); ?></h3>
			<div class="masters__attr-left">
				<span class="attr_left1"></span>
				<span class="attr_left2"><i class="fa fa-map-marker" aria-hidden="true"></i></span>
				<span class="attr_left3">Форма работы: <b>Салон</b></span>
			</div>
			<div class="masters__attr-right">
				<span class="attr-rating">4.5</span>
				<div class="attr-div-rating">
					<ul class="category_cinfo-ratings" style="display:none">
						<li><i class="fa fa-star" aria-hidden="true"></i></li>
						<li><i class="fa fa-star" aria-hidden="true"></i></li>
						<li><i class="fa fa-star" aria-hidden="true"></i></li>
						<li><i class="fa fa-star" aria-hidden="true"></i></li>
						<li><i class="fa fa-star-half" aria-hidden="true"></i></li>
					</ul>
					<span style="display:none"></span>
				</div>
				<div class="clearFloat"></div>
			</div>
			<div class="clearFloat"></div>
		</div>
		<div class="masters__gall-small">
			<span class="masters__gall-small-count"><i>Еще 0<br> фотографий</i></span>
			<div class="masters__small-img">
				<div style="background-image: url('<?php echo $avatarUrl ? $this->escape($avatarUrl) : $defaultImg; ?>'); width: 100%; display: inline-block;" class="masters__small-img-item"></div>
			</div>
			<div class="clearFloat"></div>
		</div>
	</div>
	<div class="clearFloat"></div>
</div>
<style>
.view_profile-tabs .z-container { position: relative; min-height: 1px; }
.view_profile-tabs .z-container .z-content { position: relative !important; transition: opacity 0.25s ease-out; }
.view_profile-tabs .z-container .z-content.z-tab-animating { position: absolute !important; top: 0; left: 0; right: 0; width: 100%; box-sizing: border-box; }
.view_profile-services { margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid #e0e0e0; }
.view_profile-services .profile-services-block { margin-bottom: 1.5rem; }
.view_profile-services .profile-services-block:last-child { margin-bottom: 0; }
.view_profile-services .profile-services-title { margin: 0 0 0.75rem; font-size: 1.1rem; font-weight: 600; color: #333; }
.view_profile-services .profile-services-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 1rem; }
.view_profile-services .profile-services-card { background: #f8f9fa; border-radius: 6px; border: 1px solid #e9ecef; overflow: hidden; }
.view_profile-services .profile-services-card__head { padding: 0.6rem 0.9rem; font-weight: 600; font-size: 0.95rem; background: #e9ecef; color: #495057; }
.view_profile-services .profile-services-card__list { margin: 0; padding: 0.5rem 0.9rem 0.75rem; list-style: none; font-size: 0.9rem; line-height: 1.5; color: #212529; }
.view_profile-services .profile-services-card__list li { padding: 0.25rem 0; border-bottom: 1px solid #eee; }
.view_profile-services .profile-services-card__list li:last-child { border-bottom: none; }
.view_profile-services .profile-services-block--stocks .profile-services-card { border-color: #ffeaa7; }
.view_profile-services .profile-services-block--stocks .profile-services-card__head { background: #fff3cd; color: #856404; }
@media (max-width: 576px) {
	.view_profile-services .profile-services-grid { grid-template-columns: 1fr; gap: 0.75rem; }
	.view_profile-services .profile-services-card__head { padding: 0.5rem 0.75rem; font-size: 0.9rem; }
	.view_profile-services .profile-services-card__list { padding: 0.4rem 0.75rem 0.6rem; font-size: 0.85rem; }
}
</style>
<script>
(function(){
	var tabs = document.querySelectorAll('#jsn-profile-tabs .z-tab');
	var contents = document.querySelectorAll('#jsn-form .z-container .z-content');
	if (!tabs.length || !contents.length) return;
	var activeIndex = 0;
	function showTab(index) {
		if (index === activeIndex) return;
		var prev = contents[activeIndex];
		var next = contents[index];
		tabs.forEach(function(t, i){ t.classList.toggle('z-active', i === index); });
		contents.forEach(function(c, i){
			c.classList.toggle('z-active', i === index);
		});
		next.style.display = 'block';
		next.style.opacity = '0';
		next.offsetHeight;
		prev.classList.add('z-tab-animating');
		prev.style.opacity = '0';
		next.style.opacity = '1';
		function onPrevEnd() {
			prev.removeEventListener('transitionend', onPrevEnd);
			prev.style.display = 'none';
			prev.classList.remove('z-tab-animating');
			prev.style.opacity = '';
		}
		prev.addEventListener('transitionend', onPrevEnd);
		activeIndex = index;
	}
	contents.forEach(function(c, i){
		c.style.display = i === 0 ? 'block' : 'none';
		if (i === 0) c.style.opacity = '1';
	});
	tabs.forEach(function(tab, index){
		var a = tab.querySelector('a');
		if (a) a.addEventListener('click', function(e){ e.preventDefault(); showTab(index); });
	});
})();
</script>
<?php if (!$isOwn && (int) $this->data->id > 0) : ?>
<script>
(function(){
	var toggle = document.getElementById('lk-booking-toggle');
	var block = document.getElementById('lk-booking-block');
	var form = document.getElementById('lk-booking-form');
	var dateEl = document.getElementById('lk-booking-date');
	var timeEl = document.getElementById('lk-booking-time');
	if (!toggle || !block || !form) return;
	function setDefaultDateTime() {
		if (!dateEl || !timeEl) return;
		var now = new Date();
		var in30 = new Date(now.getTime() + 30 * 60 * 1000);
		var rounded = Math.ceil(in30.getMinutes() / 15) * 15;
		in30.setMinutes(rounded % 60);
		if (rounded >= 60) in30.setHours(in30.getHours() + 1);
		dateEl.value = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0') + '-' + String(now.getDate()).padStart(2, '0');
		timeEl.value = String(in30.getHours()).padStart(2, '0') + ':' + String(in30.getMinutes()).padStart(2, '0');
	}
	toggle.addEventListener('click', function(){
		var open = block.style.display !== 'none';
		block.style.display = open ? 'none' : 'block';
		toggle.setAttribute('aria-expanded', open ? 'false' : 'true');
		if (!open) setDefaultDateTime();
	});
	var isUserLoggedIn = <?php echo $user->id > 0 ? 'true' : 'false'; ?>;
	var pendingBookingData = null;
	var lkBookingAjaxUrl = <?php echo json_encode(Route::_('index.php?option=com_ajax&group=ajax&plugin=lkbooking&format=json', false)); ?>;
	var lkOwnProfileUrl = <?php echo json_encode(Route::_('index.php?option=com_users&view=profile', false)); ?>;

	window.LK_BOOKING = {
		ajaxUrl: lkBookingAjaxUrl,
		ownProfileUrl: lkOwnProfileUrl,
		submitPending: function(pendingData, formToken) {
			if (!pendingData || !dateEl || !timeEl || !form) return Promise.reject('no data');
			dateEl.value = pendingData.date || '';
			timeEl.value = pendingData.time || '';
			var serviceEl = document.getElementById('lk-booking-service');
			var serviceNameEl = document.getElementById('lk-booking-service-name');
			if (serviceEl && pendingData.serviceId) serviceEl.value = pendingData.serviceId;
			if (serviceNameEl && pendingData.serviceName) serviceNameEl.value = pendingData.serviceName;
			var timeCombinedEl = document.getElementById('lk-booking-time-combined');
			var serviceNameHiddenEl = document.getElementById('lk-booking-service-name-hidden');
			if (timeCombinedEl) timeCombinedEl.value = (pendingData.date || '') + ' ' + (pendingData.time || '');
			if (serviceNameHiddenEl) serviceNameHiddenEl.value = pendingData.serviceName || '';
			var localDate = new Date((pendingData.date || '') + 'T' + (pendingData.time || ''));
			var timeUtc = isNaN(localDate.getTime()) ? '' : localDate.toISOString();
			var fd = new FormData(form);
			if (formToken) fd.set(formToken, '1');
			if (timeUtc) fd.set('time_utc', timeUtc);
			try { fd.set('timezone', Intl.DateTimeFormat().resolvedOptions().timeZone); } catch (e) {}
			return fetch(lkBookingAjaxUrl, { method: 'POST', body: fd, credentials: 'same-origin' })
				.then(function(r){ return r.json(); })
				.then(function(data){
					var res = (data.data && typeof data.data.success !== 'undefined') ? data.data : data;
					if (res && res.success) return;
					throw new Error(res && res.message ? res.message : 'Ошибка записи');
				});
		}
	};

	function getBookingFormData() {
		var serviceEl = document.getElementById('lk-booking-service');
		var serviceNameEl = document.getElementById('lk-booking-service-name');
		if (!dateEl || !timeEl) return null;
		var serviceName = '';
		var serviceId = '';
		if (serviceEl && serviceEl.selectedIndex > 0) {
			serviceName = serviceEl.options[serviceEl.selectedIndex].getAttribute('data-name') || serviceEl.options[serviceEl.selectedIndex].text;
			serviceId = serviceEl.value;
		} else if (serviceNameEl) {
			serviceName = serviceNameEl.value.trim();
		}
		if (!serviceName) return null;
		return {
			date: dateEl.value,
			time: timeEl.value,
			serviceName: serviceName,
			serviceId: serviceId
		};
	}

	function submitBookingForm() {
		var msgEl = document.getElementById('lk-booking-msg');
		var submitBtn = document.getElementById('lk-booking-submit');
		if (!dateEl || !timeEl || !msgEl || !submitBtn) return;

		var formData = getBookingFormData();
		if (!formData) {
			msgEl.textContent = 'Заполните все поля';
			msgEl.style.color = '#c00';
			return;
		}

		var localDate = new Date(formData.date + 'T' + formData.time);
		var timeUtc = isNaN(localDate.getTime()) ? '' : localDate.toISOString();
		var timeStr = formData.date + ' ' + formData.time;
		var timeCombinedEl = document.getElementById('lk-booking-time-combined');
		var serviceNameHiddenEl = document.getElementById('lk-booking-service-name-hidden');
		if (timeCombinedEl) timeCombinedEl.value = timeStr;
		if (serviceNameHiddenEl) serviceNameHiddenEl.value = formData.serviceName;

		var fd = new FormData(form);
		if (timeUtc) fd.set('time_utc', timeUtc);
		try { fd.set('timezone', Intl.DateTimeFormat().resolvedOptions().timeZone); } catch (e) {}

		msgEl.textContent = '';
		submitBtn.disabled = true;
		fetch('<?php echo Route::_('index.php?option=com_ajax&group=ajax&plugin=lkbooking&format=json', false); ?>', { method: 'POST', body: fd, credentials: 'same-origin' })
			.then(function(r){ return r.json(); })
			.then(function(data){
				var res = (data.data && typeof data.data.success !== 'undefined') ? data.data : data;
				if (res.success) {
					msgEl.textContent = res.message || 'Вы записались!';
					msgEl.style.color = '#0a0';
					msgEl.style.fontWeight = 'bold';
					form.querySelectorAll('input:not([type="hidden"]), select, textarea').forEach(function(el){ el.disabled = true; });
					submitBtn.style.display = 'none';
					sessionStorage.removeItem('lk_pending_booking');
					setTimeout(function(){
						window.location.href = '<?php echo Route::_('index.php?option=com_users&view=profile', false); ?>';
					}, 1500);
				} else {
					msgEl.textContent = res.message || 'Ошибка';
					msgEl.style.color = '#c00';
				}
			})
			.catch(function(){ msgEl.textContent = 'Ошибка запроса'; msgEl.style.color = '#c00'; })
			.finally(function(){ submitBtn.disabled = false; });
	}

	try {
		var savedData = sessionStorage.getItem('lk_pending_booking');
		if (savedData && isUserLoggedIn) {
			pendingBookingData = JSON.parse(savedData);
			if (pendingBookingData && pendingBookingData.masterId == <?php echo (int) $this->data->id; ?>) {
				dateEl.value = pendingBookingData.date || '';
				timeEl.value = pendingBookingData.time || '';
				var serviceEl = document.getElementById('lk-booking-service');
				var serviceNameEl = document.getElementById('lk-booking-service-name');
				if (serviceEl && pendingBookingData.serviceId) {
					serviceEl.value = pendingBookingData.serviceId;
				} else if (serviceNameEl && pendingBookingData.serviceName) {
					serviceNameEl.value = pendingBookingData.serviceName;
				}
				block.style.display = 'block';
				toggle.setAttribute('aria-expanded', 'true');
				setTimeout(function() {
					submitBookingForm();
				}, 500);
			}
		}
	} catch (e) {}

	form.addEventListener('submit', function(e){
		e.preventDefault();
		if (!isUserLoggedIn) {
			var formData = getBookingFormData();
			if (!formData) {
				document.getElementById('lk-booking-msg').textContent = 'Заполните все поля';
				document.getElementById('lk-booking-msg').style.color = '#c00';
				return;
			}
			formData.masterId = <?php echo (int) $this->data->id; ?>;
			try {
				sessionStorage.setItem('lk_pending_booking', JSON.stringify(formData));
			} catch (e) {}

			if (window.QuickAuth && typeof window.QuickAuth.show === 'function') {
				window.QuickAuth.show('', {
					title: 'Авторизуйтесь, чтобы записаться',
					callback: function(res) {
						var raw = null;
						try { raw = sessionStorage.getItem('lk_pending_booking'); } catch (e) {}
						if (raw && window.LK_BOOKING && typeof window.LK_BOOKING.submitPending === 'function') {
							var data = JSON.parse(raw);
							var formToken = (res && res.form_token) ? res.form_token : null;
							window.LK_BOOKING.submitPending(data, formToken).then(function() {
								try { sessionStorage.removeItem('lk_pending_booking'); } catch (e) {}
								window.location.href = window.LK_BOOKING.ownProfileUrl || (res && res.redirect) || '';
							}).catch(function() {
								try { sessionStorage.removeItem('lk_pending_booking'); } catch (e) {}
								window.location.href = window.LK_BOOKING.ownProfileUrl || (res && res.redirect) || '';
							});
						} else {
							window.location.href = (res && res.redirect) || window.LK_BOOKING && window.LK_BOOKING.ownProfileUrl || '';
							if (!(res && res.redirect) && !(window.LK_BOOKING && window.LK_BOOKING.ownProfileUrl)) location.reload();
						}
					}
				});
			} else {
				document.getElementById('lk-booking-msg').textContent = 'Для записи необходима авторизация';
				document.getElementById('lk-booking-msg').style.color = '#c00';
			}
			return;
		}
		submitBookingForm();
	});
})();
</script>
<?php endif; ?>
<?php if ($isOwn) :
	$firebaseConfig = is_file(JPATH_ROOT . '/configuration/firebase-config.php') ? (include JPATH_ROOT . '/configuration/firebase-config.php') : [];
	if (is_array($firebaseConfig) && !empty($firebaseConfig['apiKey'])) :
?>
<script>
window.PUSHNOTIFY_BASE = <?php echo json_encode($pushnotifyBase); ?>;
window.PUSHNOTIFY_SW_URL = <?php echo json_encode($pushnotifySwUrl); ?>;
window.PUSHNOTIFY_TOKEN_NAME = <?php echo json_encode($pushnotifyTokenName); ?>;
window.PUSHNOTIFY_TOKEN_VALUE = <?php echo json_encode($pushnotifyTokenValue); ?>;
window.FIREBASE_VAPID_KEY = <?php echo json_encode($firebaseConfig['vapidKey'] ?? ''); ?>;
window.FIREBASE_CONFIG = <?php echo json_encode([
	'apiKey' => $firebaseConfig['apiKey'] ?? '',
	'authDomain' => $firebaseConfig['authDomain'] ?? '',
	'projectId' => $firebaseConfig['projectId'] ?? '',
	'storageBucket' => $firebaseConfig['storageBucket'] ?? '',
	'messagingSenderId' => $firebaseConfig['messagingSenderId'] ?? '',
	'appId' => $firebaseConfig['appId'] ?? '',
]); ?>;
</script>
<script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-app-compat.js"></script>
<script>
(function(){ if (window.firebase && window.FIREBASE_CONFIG) { try { window.firebase.app(); } catch (e) { window.firebase.initializeApp(window.FIREBASE_CONFIG); } } })();
</script>
<script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-messaging-compat.js"></script>
<script src="<?php echo $pushnotifyRoot; ?>/media/com_pushnotify/js/push-notifications.js"></script>
<script>
(function(){
	try {
		var tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
		if (tz && window.PUSHNOTIFY_BASE) {
			var u = window.PUSHNOTIFY_BASE + (window.PUSHNOTIFY_BASE.indexOf('?') === -1 ? '?' : '&') + 'task=display.setTimezone&format=json&timezone=' + encodeURIComponent(tz);
			fetch(u, { method: 'GET', credentials: 'same-origin' }).catch(function(){});
		}
	} catch (e) {}
})();
</script>
<script>
(function() {
	var statusEl = document.getElementById('pushnotify-status');
	var btn = document.getElementById('pushnotify-subscribe-btn');
	var refreshBtn = document.getElementById('pushnotify-refresh-btn');
	var wrap = document.getElementById('pushnotify-toggle-wrap');
	var cb = document.getElementById('pushnotify-enabled');
	var testBtn = document.getElementById('pushnotify-test-btn');
	if (!statusEl || !btn || !window.PushNotify) return;

	var baseUrl = window.PUSHNOTIFY_BASE || '';
	var tokenName = window.PUSHNOTIFY_TOKEN_NAME || '';
	var tokenValue = window.PUSHNOTIFY_TOKEN_VALUE || '';
	function getSep(u) { return (u && u.indexOf('?') === -1) ? '?' : '&'; }
	function getPreferencesWithToken(fcmToken, callback) {
		var url = baseUrl + getSep(baseUrl) + 'task=display.getPreferences&format=json&' + encodeURIComponent(tokenName) + '=' + encodeURIComponent(tokenValue);
		if (fcmToken) url += '&token=' + encodeURIComponent(fcmToken);
		fetch(url, { credentials: 'same-origin' }).then(function(r) { return r.json(); }).then(callback).catch(function() { if (callback) callback({}); });
	}

	function setStatus(t) { statusEl.textContent = t || '—'; }
	function showToggle(show) { wrap.style.display = show ? 'inline' : 'none'; }
	function setBtn(show) { btn.style.display = show ? 'inline-block' : 'none'; }
	function setRefreshBtn(show) { if (refreshBtn) refreshBtn.style.display = show ? 'inline-block' : 'none'; }

	function applyUI(r) {
		if (!r || !r.success) return;
		cb.checked = !!r.notifications_enabled;
		var tokenRegistered = r.current_token_registered === true;
		if (r.subscribed && tokenRegistered) {
			setStatus('Подписаны');
			setBtn(false);
			setRefreshBtn(true);
			showToggle(true);
		} else if (r.subscribed && !tokenRegistered) {
			setStatus('Подписка не активна на этом устройстве');
			showToggle(false);
			setBtn(true);
			setRefreshBtn(true);
		} else {
			setStatus('Подписка не активна');
			showToggle(false);
			setBtn(true);
			setRefreshBtn(false);
		}
	}

	getPreferencesWithToken(null, function(r) {
		applyUI(r);
		if (!('Notification' in window) || Notification.permission !== 'granted' || !window.firebase || !window.FIREBASE_CONFIG) return;
		var swUrl = window.PUSHNOTIFY_SW_URL || window.PushNotify.swUrl;
		navigator.serviceWorker.register(swUrl, { scope: '/' }).then(function(reg) {
			return reg.active ? Promise.resolve(reg) : new Promise(function(resolve) {
				reg.addEventListener('updatefound', function() {
					var n = reg.installing;
					if (n) n.addEventListener('statechange', function() { if (n.state === 'activated') resolve(reg); });
				});
				setTimeout(function() { resolve(reg); }, 3000);
			});
		}).then(function(swRegistration) {
			var app = window.firebase.app().name ? window.firebase.app() : window.firebase.initializeApp(window.FIREBASE_CONFIG);
			var messaging = app.messaging();
			return messaging.getToken({
				vapidKey: window.FIREBASE_VAPID_KEY || undefined,
				serviceWorkerRegistration: swRegistration
			});
		}).then(function(token) {
			if (token) getPreferencesWithToken(token, applyUI);
		}).catch(function() {});
	});

	function sendTokenToServer(token) {
		if (!token) return;
		var ua = navigator.userAgent;
		var device = /Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(ua) ? 'android' : 'desktop';
		var browser = ua.indexOf('Chrome') >= 0 ? 'chrome' : (ua.indexOf('Firefox') >= 0 ? 'firefox' : (ua.indexOf('Edg') >= 0 ? 'edge' : ''));
		window.PushNotify.subscribe(token, device, browser, function(res) {
			if (res && res.success) getPreferencesWithToken(token, applyUI);
		});
	}

	function silentRefreshToken() {
		if (!('Notification' in window) || Notification.permission !== 'granted' || !window.firebase || !window.FIREBASE_CONFIG) return;
		var swUrl = window.PUSHNOTIFY_SW_URL || window.PushNotify.swUrl;
		navigator.serviceWorker.ready.then(function() {
			return navigator.serviceWorker.getRegistration('/');
		}).then(function(reg) {
			if (!reg) return navigator.serviceWorker.register(swUrl, { scope: '/' });
			return reg;
		}).then(function(reg) {
			var app;
			try { app = window.firebase.app(); } catch (e) { app = window.firebase.initializeApp(window.FIREBASE_CONFIG); }
			return app.messaging().getToken({
				vapidKey: window.FIREBASE_VAPID_KEY || undefined,
				serviceWorkerRegistration: reg
			});
		}).then(function(token) {
			if (token) sendTokenToServer(token);
		}).catch(function() {});
	}

	document.addEventListener('visibilitychange', function() {
		if (document.visibilityState === 'visible') silentRefreshToken();
	});
	setInterval(silentRefreshToken, 25 * 60 * 1000);

	function runSubscribeFlow() {
		if (!('Notification' in window) || !window.firebase) {
			setStatus('Браузер не поддерживает уведомления');
			return;
		}
		Notification.requestPermission().then(function(perm) {
			if (perm !== 'granted') {
				setStatus('Разрешение отклонено');
				return;
			}
			setStatus('Регистрация…');
			var swUrl = window.PUSHNOTIFY_SW_URL || window.PushNotify.swUrl;
			navigator.serviceWorker.getRegistrations().then(function(regs) {
				return Promise.all(regs.map(function(r) { return r.unregister(); }));
			}).then(function() {
				return navigator.serviceWorker.register(swUrl, { scope: '/' });
			}).then(function(reg) {
				return new Promise(function(resolve) {
					if (reg.active) return resolve(reg);
					reg.addEventListener('updatefound', function() {
						var n = reg.installing;
						if (n) n.addEventListener('statechange', function() { if (n.state === 'activated') resolve(reg); });
					});
					setTimeout(function() { resolve(reg); }, 5000);
				});
			}).then(function(swRegistration) {
				var app = window.firebase.app().name ? window.firebase.app() : window.firebase.initializeApp(window.FIREBASE_CONFIG);
				var messaging = app.messaging();
				return messaging.getToken({
					vapidKey: window.FIREBASE_VAPID_KEY || undefined,
					serviceWorkerRegistration: swRegistration
				}).then(function(t) { if (t) console.log('FCM token', t); return t; });
			}).then(function(token) {
				if (!token) { setStatus('Не удалось получить токен'); return; }
				sendTokenToServer(token);
				setStatus('Подписаны');
				setBtn(false);
				setRefreshBtn(true);
				showToggle(true);
			}).catch(function(e) {
				console.error('getToken error', e);
				setStatus('Ошибка: ' + (e && e.message ? e.message : 'неизвестно'));
			});
		});
	}
	btn.addEventListener('click', runSubscribeFlow);
	if (refreshBtn) refreshBtn.addEventListener('click', runSubscribeFlow);

	cb.addEventListener('change', function() {
		window.PushNotify.updatePreferences(cb.checked, function(r) {
			if (r && !r.success) setStatus(r.message || 'Ошибка сохранения');
		});
	});

	if (testBtn) {
		testBtn.addEventListener('click', function() {
			var form = new FormData();
			form.append(tokenName, tokenValue);
			testBtn.disabled = true;
			fetch(baseUrl + getSep(baseUrl) + 'task=display.sendTest&format=json', { method: 'POST', body: form, credentials: 'same-origin' })
				.then(function(r) { return r.json(); })
				.then(function(res) {
					alert(res.message || (res.success ? 'Отправлено' : 'Ошибка'));
				})
				.catch(function() { alert('Ошибка запроса'); })
				.then(function() { testBtn.disabled = false; });
		});
	}
})();
</script>
<script>
(function(){
	window.PUSHNOTIFY_BASE = window.PUSHNOTIFY_BASE || <?php echo json_encode($pushnotifyBase); ?>;
	window.PUSHNOTIFY_TOKEN_NAME = window.PUSHNOTIFY_TOKEN_NAME || <?php echo json_encode($pushnotifyTokenName); ?>;
	window.PUSHNOTIFY_TOKEN_VALUE = window.PUSHNOTIFY_TOKEN_VALUE || <?php echo json_encode($pushnotifyTokenName); ?>;
	var toggle = document.getElementById('lk-notify-toggle');
	var dropdown = document.getElementById('lk-notify-dropdown');
	var listEl = document.getElementById('lk-notify-list');
	var emptyEl = document.getElementById('lk-notify-empty');
	var loadingEl = document.getElementById('lk-notify-loading');
	var badgeEl = document.getElementById('lk-notify-badge');
	if (!toggle || !dropdown || !listEl) return;
	var baseUrl = window.PUSHNOTIFY_BASE || '';
	var tokenName = window.PUSHNOTIFY_TOKEN_NAME || '';
	var tokenValue = window.PUSHNOTIFY_TOKEN_VALUE || '';
	function getSep(u) { return (u && u.indexOf('?') === -1) ? '?' : '&'; }
	function loadInbox(cb) {
		if (!baseUrl) { if (cb) cb(); return; }
		loadingEl.style.display = 'block';
		emptyEl.style.display = 'none';
		listEl.innerHTML = '';
		fetch(baseUrl + getSep(baseUrl) + 'task=display.getInbox&format=json')
			.then(function(r){ return r.json(); })
			.then(function(data){
				loadingEl.style.display = 'none';
				if (data && data.success && Array.isArray(data.items)) {
					if (data.unread_count > 0 && badgeEl) {
						badgeEl.textContent = data.unread_count > 99 ? '99+' : data.unread_count;
						badgeEl.style.display = 'inline-block';
					} else if (badgeEl) {
						badgeEl.style.display = 'none';
					}
					if (data.items.length === 0) {
						emptyEl.style.display = 'block';
					} else {
						data.items.forEach(function(it){
							var read = !!it.read_at;
							var div = document.createElement('div');
							div.className = 'lk-notify-item' + (read ? ' lk-notify-item-read' : '');
							div.setAttribute('data-id', it.id);
							div.style.cssText = 'padding:10px 12px; border-bottom:1px solid #eee;';
							if (read) div.style.backgroundColor = '#f5f5f5';
							var title = document.createElement('div');
							title.style.fontWeight = 'bold';
							title.textContent = it.title || '';
							var body = document.createElement('div');
							body.style.fontSize = '0.9em';
							body.style.color = '#555';
							body.textContent = (it.body || '').substring(0, 120) + ((it.body && it.body.length > 120) ? '…' : '');
							var meta = document.createElement('div');
							meta.style.fontSize = '0.8em';
							meta.style.color = '#999';
							meta.style.marginTop = '4px';
							var d = it.event_time_utc || it.created_at;
							if (d) {
								var iso = (d + '').replace(' ', 'T');
								if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(iso) && iso.indexOf('Z') === -1 && iso.indexOf('+') === -1) iso += 'Z';
								try {
									var dateObj = new Date(iso);
									if (!isNaN(dateObj.getTime())) meta.textContent = dateObj.toLocaleString(undefined, { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
									else meta.textContent = d;
								} catch (e) { meta.textContent = d; }
							}
							var acts = document.createElement('div');
							acts.style.marginTop = '6px';
							if (!read) {
								var btnRead = document.createElement('button');
								btnRead.type = 'button';
								btnRead.className = 'btn btn-xs btn-default';
								btnRead.textContent = 'Прочитано';
								btnRead.addEventListener('click', function(){ markRead(it.id, div); });
								acts.appendChild(btnRead);
								acts.appendChild(document.createTextNode(' '));
							}
							var btnDel = document.createElement('button');
							btnDel.type = 'button';
							btnDel.className = 'btn btn-xs btn-default';
							btnDel.textContent = 'Удалить';
							btnDel.addEventListener('click', function(){ deleteNotif(it.id, div); });
							acts.appendChild(btnDel);
							div.appendChild(title);
							div.appendChild(body);
							div.appendChild(meta);
							div.appendChild(acts);
							listEl.appendChild(div);
						});
					}
				}
				if (cb) cb();
			})
			.catch(function(){ loadingEl.style.display = 'none'; if (cb) cb(); });
	}
	function markRead(id, rowEl) {
		var fd = new FormData();
		fd.append(tokenName, tokenValue);
		fd.append('id', id);
		fetch(baseUrl + getSep(baseUrl) + 'task=display.markRead&format=json', { method: 'POST', body: fd, credentials: 'same-origin' })
			.then(function(r){ return r.json(); })
			.then(function(data){
				if (data && data.success && rowEl) {
					rowEl.classList.add('lk-notify-item-read');
					rowEl.style.backgroundColor = '#f5f5f5';
					var acts = rowEl.querySelector('div:last-child');
					if (acts) {
						var br = acts.querySelector('button');
						if (br && br.textContent === 'Прочитано') br.remove();
					}
					var n = badgeEl ? parseInt(badgeEl.textContent, 10) : 0;
					if (n > 1 && badgeEl) badgeEl.textContent = n - 1;
					else if (badgeEl) badgeEl.style.display = 'none';
				}
			});
	}
	function deleteNotif(id, rowEl) {
		var fd = new FormData();
		fd.append(tokenName, tokenValue);
		fd.append('id', id);
		fetch(baseUrl + getSep(baseUrl) + 'task=display.deleteNotification&format=json', { method: 'POST', body: fd, credentials: 'same-origin' })
			.then(function(r){ return r.json(); })
			.then(function(data){
				if (data && data.success && rowEl) {
					rowEl.remove();
					var items = listEl.querySelectorAll('.lk-notify-item');
					if (items.length === 0) {
						emptyEl.style.display = 'block';
						var n = badgeEl ? parseInt(badgeEl.textContent, 10) : 0;
						if (n > 1 && badgeEl) badgeEl.textContent = n - 1;
						else if (badgeEl) badgeEl.style.display = 'none';
					}
				}
			});
	}
	toggle.addEventListener('click', function(e){
		e.stopPropagation();
		var open = dropdown.style.display === 'block';
		if (!open) {
			dropdown.style.display = 'block';
			toggle.setAttribute('aria-expanded', 'true');
			loadInbox();
		} else {
			dropdown.style.display = 'none';
			toggle.setAttribute('aria-expanded', 'false');
		}
	});
	document.addEventListener('click', function(){
		dropdown.style.display = 'none';
		toggle.setAttribute('aria-expanded', 'false');
	});
	dropdown.addEventListener('click', function(e){ e.stopPropagation(); });
	loadInbox();
})();
</script>
<?php
	endif;
endif; ?>
