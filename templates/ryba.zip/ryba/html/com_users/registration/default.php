<?php

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

$wa = $this->getDocument()->getWebAssetManager();
$wa->useScript('keepalive')->useScript('form.validate');

if ($this->form->getField('avatar')) {
	$this->form->setFieldAttribute('avatar', 'default', 'templates/ryba/images/avatar_upload.png');
}
if ($this->form->getField('portfolio_field')) {
	$this->form->setFieldAttribute('portfolio_field', 'default', 'templates/ryba/images/3.png');
}

$captchaEnabled = !empty($this->captchaEnabled);
$fieldsets = $this->form->getFieldsets();
$profileFields = $this->form->getFieldset('profile');
$profileClientNames = ['phone'];
$profileMasterNames = ['lastname', 'city', 'region', 'address1', 'address2', 'website', 'aboutme', 'master_zatochka_remont'];

?>
<div class="test registration reg-type-page<?php echo $this->pageclass_sfx; ?>">
	<?php if ($this->params->get('show_page_heading')) : ?>
	<div class="container header-bot">
		<h1><?php echo $this->escape($this->params->get('page_heading')); ?></h1>
		<div class="clearFloat"></div>
	</div>
	<?php endif; ?>
	<form id="member-registration" action="<?php echo Route::_('index.php?option=com_users&task=registration.register'); ?>" method="post" class="form-validate form-horizontal well com-users-registration-form" enctype="multipart/form-data">
		<div class="reg-form-wrap">
			<fieldset id="fieldset-default">
				<?php
				$defaultFields = $this->form->getFieldset('default');
				$defaultByName = [];
				foreach ($defaultFields as $f) {
					$defaultByName[$f->getAttribute('name')] = $f;
				}
				if (isset($defaultByName['name'])) {
					echo $defaultByName['name']->renderField();
				}
				?>
			</fieldset>
			<div id="reg-client-fields" class="reg-type-fields">
				<fieldset id="fieldset-profile-client">
					<?php
					foreach ($profileFields as $field) {
						$name = $field->getAttribute('name');
						if (in_array($name, $profileClientNames, true)) {
							echo $field->renderField();
						}
					}
					?>
				</fieldset>
			</div>
			<fieldset id="fieldset-default-2">
				<?php
				$order = ['email1', 'username', 'password1', 'password2', 'registration_type'];
				foreach ($order as $name) {
					if (!isset($defaultByName[$name])) continue;
					$f = $defaultByName[$name];
					if ($name === 'username') {
						echo '<div class="control-group js-username-hidden">';
						echo $f->renderField();
						echo '</div>';
					} elseif ($name === 'email1') {
						echo $f->renderField();
						echo '<p class="reg-field-hint">* для восстановления доступа к вашему профилю</p>';
					} else {
						echo $f->renderField();
					}
				}
				?>
			</fieldset>
			<div id="reg-master-fields" class="reg-type-fields" style="display:none;">
				<fieldset id="fieldset-profile-master">
					<?php
					foreach ($profileFields as $field) {
						$name = $field->getAttribute('name');
						if (in_array($name, $profileMasterNames, true)) {
							echo $field->renderField();
						}
					}
					?>
				</fieldset>
			</div>
			<?php
			foreach ($this->form->getFieldsets() as $fs) {
				if ($fs->name === 'default' || $fs->name === 'profile' || $fs->name === 'fields-0') {
					continue;
				}
				$fields = $this->form->getFieldset($fs->name);
				if ($fs->name === 'captcha' && $captchaEnabled && count($fields)) {
					echo '<fieldset id="' . $this->escape($fs->name) . '">';
					if (isset($fs->label)) {
						echo '<legend>' . Text::_($fs->label) . '</legend>';
					}
					echo $this->form->renderFieldset($fs->name);
					echo '</fieldset>';
				}
			}
			?>
			<div class="control-group">
				<div class="controls">
					<button type="submit" class="dale validate">
						<?php echo Text::_('JREGISTER'); ?>
					</button>
					<input type="hidden" name="option" value="com_users" />
					<input type="hidden" name="task" value="registration.register" />
				</div>
			</div>
		</div>
		<p class="reg-switch-master">
			<a href="#" id="reg-link-as-master">Вы хотите зарегистрироваться, как мастер</a>
		</p>
		<p class="reg-switch-client" style="display:none;">
			<a href="#" id="reg-link-as-client">Вернуться к регистрации клиента</a>
		</p>
		<p class="reg-login-link">
			У вас уже есть аккаунт? <a href="<?php echo Route::_('index.php?option=com_users&view=login'); ?>">Войти</a>
		</p>
		<?php echo HTMLHelper::_('form.token'); ?>
	</form>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
	var form = document.getElementById('member-registration');
	if (!form) return;
	var clientBlock = form.querySelector('#reg-client-fields');
	var masterBlock = form.querySelector('#reg-master-fields');
	var hidden = document.getElementById('jform_registration_type');
	var linkMaster = document.getElementById('reg-link-as-master');
	var linkClient = document.getElementById('reg-link-as-client');
	var switchToClient = form.querySelector('.reg-switch-client');
	var switchToMaster = form.querySelector('.reg-switch-master');
	function showClient() {
		if (clientBlock) clientBlock.style.display = '';
		if (masterBlock) masterBlock.style.display = 'none';
		if (hidden) hidden.value = 'client';
		if (switchToClient) switchToClient.style.display = 'none';
		if (switchToMaster) switchToMaster.style.display = '';
	}
	function showMaster() {
		if (clientBlock) clientBlock.style.display = '';
		if (masterBlock) masterBlock.style.display = '';
		if (hidden) hidden.value = 'master';
		if (switchToClient) switchToClient.style.display = '';
		if (switchToMaster) switchToMaster.style.display = 'none';
	}
	if (linkMaster) linkMaster.addEventListener('click', function(e) { e.preventDefault(); showMaster(); });
	if (linkClient) linkClient.addEventListener('click', function(e) { e.preventDefault(); showClient(); });
	var email1 = form.querySelector('#jform_email1');
	var username = form.querySelector('#jform_username');
	if (email1 && username) {
		function syncUsername() { username.value = email1.value.trim(); }
		email1.addEventListener('input', syncUsername);
		email1.addEventListener('change', syncUsername);
		syncUsername();
	}
	var phoneInput = form.querySelector('.js-phone-mask') || form.querySelector('input[name="jform[profile][phone]"]');
	if (phoneInput) {
		function formatPhone(digits) {
			digits = digits.replace(/\D/g, '');
			if (digits.charAt(0) === '8') digits = '7' + digits.slice(1);
			if (digits.charAt(0) !== '7') digits = '7' + digits;
			digits = digits.slice(0, 11);
			if (digits.length <= 1) return digits ? '+' + digits : '';
			var s = '+7';
			if (digits.length > 1) s += ' (' + digits.slice(1, 4);
			if (digits.length >= 4) s += ') ' + digits.slice(4, 7);
			if (digits.length >= 7) s += '-' + digits.slice(7, 9);
			if (digits.length >= 9) s += '-' + digits.slice(9, 11);
			return s;
		}
		phoneInput.placeholder = '+7 (___) ___-__-__';
		phoneInput.addEventListener('keydown', function(e) {
			if (e.key !== 'Backspace') return;
			var pos = this.selectionStart;
			var val = this.value;
			if (pos <= 0) return;
			var prev = val.charAt(pos - 1);
			if (prev >= '0' && prev <= '9') return;
			e.preventDefault();
			var digits = val.replace(/\D/g, '');
			if (digits.length <= 1) { this.value = ''; return; }
			this.value = formatPhone(digits.slice(0, -1));
			this.setSelectionRange(this.value.length, this.value.length);
		});
		phoneInput.addEventListener('input', function() {
			this.value = formatPhone(this.value);
		});
		phoneInput.addEventListener('focus', function() { if (this.value === '') this.value = '+7'; });
		phoneInput.addEventListener('blur', function() { if (this.value === '+7') this.value = ''; });
	}
});
</script>
