<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;
use Joomla\CMS\User\User;

$app   = Factory::getApplication();
$input = $app->getInput();
$tpl   = $this->template;
$tplPath = rtrim(Uri::root(), '/') . '/templates/' . $tpl . '/';

$option   = $input->getCmd('option', '');
$view     = $input->getCmd('view', '');
$layout   = $input->getCmd('layout', '');
$task     = $input->getCmd('task', '');
$itemid   = $input->getCmd('Itemid', '');
$sitename = htmlspecialchars($app->get('sitename'), ENT_QUOTES, 'UTF-8');
$menu     = $app->getMenu()->getActive();
$pageclass = $menu !== null ? $menu->getParams()->get('pageclass_sfx', '') : '';

$isHome = ($menu && (int) $menu->home === 1);
$page  = $isHome ? 'home' : 'page';
if ($option === 'com_poisk' || $option === 'com_specialists') {
	$page = 'page';
}

$this->setMetaData('viewport', 'width=device-width, initial-scale=1, maximum-scale=1');
?>
<!DOCTYPE html>
<html lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
<head>
	<meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
	<meta content="IE=edge" http-equiv="X-UA-Compatible">
	<link rel="icon" href="<?php echo $tplPath; ?>favicon.png">
	<link rel="manifest" href="<?php echo rtrim(Uri::root(), '/'); ?>/manifest.json">
	<script src="<?php echo $tplPath; ?>js/jquery.min.js"></script>
	<script src="<?php echo $tplPath; ?>js/slick.min.js"></script>
	<script src="<?php echo $tplPath; ?>js/scripts.js"></script>
	<script src="<?php echo $tplPath; ?>js/custom.js"></script>
	<script src="https://code.jquery.com/jquery-migrate-1.4.1.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.1/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.full.min.js"></script>
	<jdoc:include type="metas" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.min.css">
	<link rel="stylesheet" href="<?php echo $tplPath; ?>css/slick.css">
	<link rel="stylesheet" href="<?php echo $tplPath; ?>css/slick-theme.css">
	<link rel="stylesheet" href="<?php echo $tplPath; ?>css/tabs.min.css">
	<link rel="stylesheet" href="<?php echo $tplPath; ?>css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo $tplPath; ?>css/style.css">
	<link rel="stylesheet" href="<?php echo $tplPath; ?>css/style-ext.css">
	<jdoc:include type="styles" />
</head>
<body id="<?php echo $page; ?>" class="d-flex flex-column site <?php echo $option . ' view-' . $view . ($layout ? ' layout-' . $layout : '') . ($task ? ' task-' . $task : '') . ($itemid ? ' itemid-' . $itemid : '') . ($pageclass ? ' ' . $pageclass : ''); ?>">
	<header class="header header--desktop<?php echo $page !== 'home' ? ' single-header no_shadow' : ''; ?>">
		<div class="container d-flex">
			<div class="offcanvas">
				<jdoc:include type="modules" name="offcanvas" style="none" />
			</div>
			<div class="header__menu">
				<?php if ($this->countModules('topmenu')) : ?>
					<jdoc:include type="modules" name="topmenu" style="none" />
				<?php else :
					$jmenu = $app->getMenu();
					$default = $jmenu->getDefault();
					if ($default) :
						$topItems = $jmenu->getItems(['menutype', 'parent_id', 'published'], [$default->menutype, 1, 1]);
						$user = $app->getIdentity();
						$levels = $user ? $user->getAuthorisedViewLevels() : [];
						$topItems = $topItems ? array_filter($topItems, function ($it) use ($levels) {
							return in_array((int) $it->access, $levels, true);
						}) : [];
						if (!empty($topItems)) : ?>
					<nav class="jmoddiv jmodinside" id="mod-menu-ryba-fallback">
						<ul class="mod-menu mod-list nav">
							<?php foreach ($topItems as $mitem) :
								$href = ($mitem->type === 'url' && $mitem->params->get('url')) ? $mitem->params->get('url') : Route::_($mitem->link);
								$class = 'nav-item item-' . $mitem->id;
								if ($menu && (int) $menu->id === (int) $mitem->id) $class .= ' current';
							?>
							<li class="<?php echo $class; ?>">
								<a href="<?php echo htmlspecialchars($href); ?>"><?php echo htmlspecialchars($mitem->title); ?></a>
							</li>
							<?php endforeach; ?>
						</ul>
					</nav>
						<?php endif;
					endif;
				endif; ?>
			</div>
			<div class="header__logo">
				<a href="<?php echo Uri::root(); ?>"><img src="/images/logo.jpg" width="65" style="margin-left:-62px; margin-right: 5px" alt="Лого Vigling.ru"><?php echo $sitename; ?></a>
			</div>
		</div>
	</header>
	<header class="header header--mobile" id="header-mobile" aria-hidden="false">
		<div class="header-mobile__bar">
			<a class="header-mobile__logo" href="<?php echo Uri::root(); ?>">
				<img src="/images/logo.jpg" width="48" height="48" alt="Лого Vigling.ru">
				<span class="header-mobile__sitename"><?php echo $sitename; ?></span>
			</a>
			<button type="button" class="header-mobile__toggle" id="header-mobile-toggle" aria-label="<?php echo htmlspecialchars($app->getLanguage()->_('JTOGGLE_NAVIGATION') ?: 'Меню'); ?>" aria-expanded="false" aria-controls="header-mobile-panel">
				<span class="header-mobile__toggle-bar"></span>
				<span class="header-mobile__toggle-bar"></span>
				<span class="header-mobile__toggle-bar"></span>
			</button>
		</div>
		<div class="header-mobile__overlay" id="header-mobile-overlay" aria-hidden="true"></div>
		<div class="header-mobile__panel" id="header-mobile-panel" aria-hidden="true">
			<div class="header-mobile__panel-head">
				<button type="button" class="header-mobile__close" id="header-mobile-close" aria-label="<?php echo htmlspecialchars($app->getLanguage()->_('JCLOSE') ?: 'Закрыть'); ?>">&times;</button>
			</div>
			<div class="header-mobile__panel-body">
			<nav class="header-mobile__nav">
				<?php if ($this->countModules('topmenu')) : ?>
					<jdoc:include type="modules" name="topmenu" style="none" />
				<?php else :
					$jmenu = $app->getMenu();
					$default = $jmenu->getDefault();
					if ($default) :
						$topItems = $jmenu->getItems(['menutype', 'parent_id', 'published'], [$default->menutype, 1, 1]);
						$user = $app->getIdentity();
						$levels = $user ? $user->getAuthorisedViewLevels() : [];
						$topItems = $topItems ? array_filter($topItems, function ($it) use ($levels) {
							return in_array((int) $it->access, $levels, true);
						}) : [];
						if (!empty($topItems)) : ?>
				<ul class="mod-menu mod-list nav">
					<?php foreach ($topItems as $mitem) :
						$href = ($mitem->type === 'url' && $mitem->params->get('url')) ? $mitem->params->get('url') : Route::_($mitem->link);
						$class = 'nav-item item-' . $mitem->id;
						if ($menu && (int) $menu->id === (int) $mitem->id) $class .= ' current';
					?>
					<li class="<?php echo $class; ?>">
						<a href="<?php echo htmlspecialchars($href); ?>"><?php echo htmlspecialchars($mitem->title); ?></a>
					</li>
					<?php endforeach; ?>
				</ul>
						<?php endif;
					endif;
				endif; ?>
			</nav>
			</div>
		</div>
	</header>
	<?php if ($page === 'home' && $this->countModules('slider')) : ?>
		<section class="slider__home slider-container">
			<jdoc:include type="modules" name="slider" />
		</section>
	<?php endif; ?>
	<?php if ($page !== 'home') : ?>
		<?php $contentClass = ($option === 'com_users' && $view === 'profile') ? 'content content__single single__master view-profile view_profile' : 'content content__single single__master'; ?>
		<section id="content" class="<?php echo $contentClass; ?>" role="main">
			<div class="container">
				<?php if ($this->countModules('breadcrumbs')) : ?>
					<jdoc:include type="modules" name="breadcrumbs" style="none" />
				<?php elseif ($option === 'com_users' && $view === 'profile') : ?>
					<?php
					$profileUserId = $input->getInt('user_id', 0);
					$profileBreadName = 'Профиль';
					$profileBreadExtra = null;
					if ($profileUserId > 0) {
						$profileUser = User::getInstance($profileUserId);
						if ($profileUser && $profileUser->id) {
							$profileBreadExtra = $profileUser->name;
						}
					}
					$rootUrl = rtrim(Uri::root(), '/') . '/';
					$profileUrl = Route::_('index.php?option=com_users&view=profile');
					?>
					<div aria-label="breadcrumbs" role="navigation">
						<ul itemscope itemtype="https://schema.org/BreadcrumbList" class="breadcrumb breadcrumbs">
							<li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
								<a itemprop="item" href="<?php echo htmlspecialchars($rootUrl); ?>" class="pathway"><span itemprop="name">Главная страница</span></a>
								<meta itemprop="position" content="1">
							</li>
							<?php if ($profileBreadExtra) : ?>
							<li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
								<a itemprop="item" href="<?php echo htmlspecialchars($profileUrl); ?>" class="pathway"><span itemprop="name"><?php echo $profileBreadName; ?></span></a>
								<meta itemprop="position" content="2">
							</li>
							<li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem" class="active">
								<span itemprop="name"><?php echo htmlspecialchars($profileBreadExtra); ?></span>
								<meta itemprop="position" content="3">
							</li>
							<?php else : ?>
							<li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem" class="active">
								<span itemprop="name"><?php echo $profileBreadName; ?></span>
								<meta itemprop="position" content="2">
							</li>
							<?php endif; ?>
						</ul>
					</div>
				<?php endif; ?>
				<jdoc:include type="message" />
				<?php $sbar = $this->countModules('sidebar') ? 'w_sidebar' : 'wo_sidebar'; ?>
				<div class="cont_<?php echo $sbar; ?> ">
					<div class="cont">
						<jdoc:include type="component" />
					</div>
					<div class="sbar">
						<jdoc:include type="modules" name="sidebar" style="html5" />
					</div>
				</div>
			</div>
		</section>
	<?php endif; ?>
	<?php if ($page === 'home') : ?>
		<?php if ($this->countModules('top')) : ?>
			<jdoc:include type="modules" name="top" style="html5" />
		<?php else :
			$searchCategories = [];
			try {
				$db = Factory::getContainer()->get(\Joomla\Database\DatabaseInterface::class);
				$prefix = $db->getPrefix();
				$q = $db->getQuery(true)
					->select('id, title')
					->from($db->quoteName($prefix . 'categories'))
					->where($db->quoteName('extension') . ' = ' . $db->quote('com_content'))
					->where($db->quoteName('published') . ' = 1')
					->where('(' . $db->quoteName('parent_id') . ' = 39 OR ' . $db->quoteName('path') . ' LIKE ' . $db->quote('uslugi/%') . ' OR ' . $db->quoteName('id') . ' IN (9,10,11,12,13,14,16,17,18,19,20,21))')
					->order('title ASC');
				$db->setQuery($q);
				$searchCategories = $db->loadAssocList('id') ?: [];
			} catch (\Throwable $e) {
			}
			$searchCategoriesJson = json_encode(array_values(array_map(function ($c) { return ['id' => (int)$c['id'], 'title' => $c['title']]; }, $searchCategories)));
		?>
		<section class="search__specialists search__section">
			<div class="container">
				<div class="search__coll-left">
					<h2 class="search_title">поиск специалистов</h2>
					<span class="search__sub"></span>
					<form action="<?php echo Route::_('index.php?option=com_poisk&view=list'); ?>" method="get">
						<input type="hidden" name="search" value="1">
						<div class="jsn_search_module-ext jsn_result_poisk">
							<div class="filed filed1">
								<input type="text" id="search_service_input" placeholder="Услуга или специальность" autocomplete="off">
								<input type="hidden" name="cat_id" id="search_cat_id" value="">
							</div>
							<div class="filed filed2">
								<input type="text" name="date" placeholder="Дата" class="date-input">
							</div>
							<div class="filed filed3">
								<div class="control-group">
									<div class="controls">
										<fieldset class="checkboxes" id="at_home">
											<label class="checkbox"><input type="checkbox" name="home[]" value="1"><b>Салон</b></label>
											<label class="checkbox"><input type="checkbox" name="home[]" value="2"><b>Вызов на дом</b></label>
											<label class="checkbox"><input type="checkbox" name="home[]" value="3"><b>Мастер на дому</b></label>
										</fieldset>
									</div>
								</div>
							</div>
							<span class="form-sub">Популярные запросы: </span>
							<input type="submit" class="btn search-sbmt" value="Поиск">
						</div>
					</form>
				</div>
				<p class="search__text"></p>
				<div class="clearFloat"></div>
			</div>
		</section>
		<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.min.css">
		<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
		<script>
		(function(){
			var categories = <?php echo $searchCategoriesJson; ?>;
			jQuery(document).ready(function($){
				var $input = $('#search_service_input');
				var $catId = $('#search_cat_id');
				var $result = $('<div class="search_box-result"></div>');
				$input.after($result);
				function filterCategories(val){
					val = (val || '').toLowerCase().trim();
					if (val.length < 1) return [];
					return categories.filter(function(c){ return c.title.toLowerCase().indexOf(val) !== -1; });
				}
				$input.on('keyup', function(){
					var val = $(this).val();
					var list = filterCategories(val);
					$result.empty();
					if (list.length) {
						list.forEach(function(c){
							$result.append($('<div class="result" data-id="'+c.id+'">').text(c.title));
						});
						$result.show();
					} else {
						$result.hide();
					}
				});
				$input.on('focus', function(){
					if ($(this).val().length > 0 && $result.children().length) $result.show();
				});
				$(document).on('click', function(e){
					if (!$(e.target).closest('.filed1').length) $result.hide();
				});
				$result.on('click', '> div', function(){
					$catId.val($(this).data('id'));
					$input.val($(this).text());
					$result.hide().empty();
				});
				$('.filed2').on('focus', 'input', function(){
					if (!$(this).hasClass('hasDatepicker')) {
						$.datepicker.regional['ru'] = {closeText:'Закрыть',prevText:'&lt;Пред',nextText:'След&gt;',currentText:'Сегодня',monthNames:['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'],monthNamesShort:['Янв','Фев','Мар','Апр','Май','Июн','Июл','Авг','Сен','Окт','Ноя','Дек'],dayNames:['воскресенье','понедельник','вторник','среда','четверг','пятница','суббота'],dayNamesShort:['вск','пнд','втр','срд','чтв','птн','сбт'],dayNamesMin:['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],weekHeader:'Не',dateFormat:'dd.mm.yy',firstDay:1,isRTL:false,yearSuffix:''};
						$.datepicker.setDefaults($.datepicker.regional['ru']);
						$('.filed2 input').datepicker({minDate:'now'});
					}
				});
			});
		})();
		</script>
		<?php endif; ?>
		<section class="search__catalog">
			<div class="container">
				<h2>поиск по услугам</h2>
				<span class="service__sub"></span>
				<?php
				$serviceLinks = [
					16 => 'Волосы',
					10 => 'Ресницы',
					18 => 'Ногти',
					12 => 'Косметология',
					13 => 'Эпиляция',
					14 => 'Визаж',
				];
				$serviceImages = ['service1.png', 'service2.png', 'service3.png', 'service4.png', 'service5.png', 'service6.png'];
				$si = 0;
				?>
				<div>
					<?php foreach ($serviceLinks as $catId => $label) : ?>
					<div class="service__item">
						<div style="background-image: url('/images/<?php echo $serviceImages[$si]; ?>')" class="service__img"><div></div></div>
						<a href="<?php echo Route::_('index.php?option=com_poisk&view=list&cat_id=' . (int) $catId); ?>"><?php echo htmlspecialchars($label); ?></a>
					</div>
					<?php $si++; endforeach; ?>
					<div class="clearFloat"></div>
				</div>
			</div>
		</section>
	<?php endif; ?>
	<?php if ($this->countModules('addmaster')) : ?>
		<section class="info__box">
			<div class="container">
				<jdoc:include type="modules" name="addmaster" style="none" />
			</div>
		</section>
	<?php endif; ?>
	<?php if ($this->countModules('loadapps')) : ?>
		<section class="app">
			<div class="container">
				<jdoc:include type="modules" name="loadapps" style="none" />
				<div class="clearFloat"></div>
			</div>
		</section>
	<?php endif; ?>
	<?php if ($this->countModules('topposts')) : ?>
		<section class="news">
			<div class="container2">
				<jdoc:include type="modules" name="topposts" style="none" />
			</div>
		</section>
	<?php endif; ?>
	<footer class="footer">
		<div class="container">
			<a class="footer__logo" href="<?php echo Uri::root(); ?>"><?php echo $sitename; ?></a>
			<jdoc:include type="modules" name="bottommenu" style="none" />
			<div class="clearFloat"></div>
		</div>
		<div class="container">
			<span class="copy">@ Все права защищены. 2019-<?php echo date('Y'); ?></span>
		</div>
	</footer>
	<jdoc:include type="modules" name="debug" style="none" />
	<jdoc:include type="scripts" />
	<?php
	$pushnotifyUser = $app->getIdentity();
	$pushnotifyLoggedIn = $pushnotifyUser && (int) $pushnotifyUser->id > 0;
	$pushnotifyBase = $pushnotifyLoggedIn ? Route::_('index.php?option=com_pushnotify') : '';
	$pushnotifySwUrl = rtrim(Uri::root(), '/') . '/firebase-messaging-sw.js';
	$pushnotifyRoot = rtrim(Uri::root(), '/');
	$pushnotifyTokenName = $pushnotifyLoggedIn ? Session::getFormToken() : '';
	$pushnotifyTokenValue = $pushnotifyLoggedIn ? '1' : '';
	$pushnotifyFirebaseConfig = [];
	if ($pushnotifyLoggedIn && is_file(JPATH_ROOT . '/configuration/firebase-config.php')) {
		$pushnotifyFirebaseConfig = (include JPATH_ROOT . '/configuration/firebase-config.php');
		if (!is_array($pushnotifyFirebaseConfig)) $pushnotifyFirebaseConfig = [];
	}
	$pushnotifyHasFirebase = $pushnotifyLoggedIn && !empty($pushnotifyFirebaseConfig['apiKey']);
	?>
	<?php if ($pushnotifyHasFirebase) : ?>
	<script>
		window.PUSHNOTIFY_GLOBAL = true;
		window.PUSHNOTIFY_BASE = <?php echo json_encode($pushnotifyBase); ?>;
		window.PUSHNOTIFY_SW_URL = <?php echo json_encode($pushnotifySwUrl); ?>;
		window.PUSHNOTIFY_TOKEN_NAME = <?php echo json_encode($pushnotifyTokenName); ?>;
		window.PUSHNOTIFY_TOKEN_VALUE = <?php echo json_encode($pushnotifyTokenValue); ?>;
		window.FIREBASE_VAPID_KEY = <?php echo json_encode($pushnotifyFirebaseConfig['vapidKey'] ?? ''); ?>;
		window.FIREBASE_CONFIG = <?php echo json_encode([
			'apiKey' => $pushnotifyFirebaseConfig['apiKey'] ?? '',
			'authDomain' => $pushnotifyFirebaseConfig['authDomain'] ?? '',
			'projectId' => $pushnotifyFirebaseConfig['projectId'] ?? '',
			'storageBucket' => $pushnotifyFirebaseConfig['storageBucket'] ?? '',
			'messagingSenderId' => $pushnotifyFirebaseConfig['messagingSenderId'] ?? '',
			'appId' => $pushnotifyFirebaseConfig['appId'] ?? '',
		]); ?>;
	</script>
	<div class="modal fade" id="pushnotify-prompt-modal" tabindex="-1" role="dialog" aria-labelledby="pushnotify-prompt-title" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="pushnotify-prompt-title">Уведомления</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Закрыть"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body">
					<p>Получайте напоминания о записях и приёмах. Включить push-уведомления?</p>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal" id="pushnotify-prompt-later">Позже</button>
					<button type="button" class="btn btn-primary" id="pushnotify-prompt-subscribe">Включить</button>
				</div>
			</div>
		</div>
	</div>
	<script>
		(function() {
			var modalEl = document.getElementById('pushnotify-prompt-modal');
			var laterBtn = document.getElementById('pushnotify-prompt-later');
			var subscribeBtn = document.getElementById('pushnotify-prompt-subscribe');
			if (!modalEl || !window.PUSHNOTIFY_BASE || !('Notification' in window)) return;
			if (sessionStorage.getItem('pushnotify_prompt_shown')) return;
			var base = window.PUSHNOTIFY_BASE;
			var sep = base.indexOf('?') === -1 ? '?' : '&';
			var tokenName = window.PUSHNOTIFY_TOKEN_NAME || '';
			var tokenValue = window.PUSHNOTIFY_TOKEN_VALUE || '1';
			var prefsUrl = base + sep + 'task=display.getPreferences&format=json&' + encodeURIComponent(tokenName) + '=' + encodeURIComponent(tokenValue);
			fetch(prefsUrl, { credentials: 'same-origin' }).then(function(r) { return r.json(); }).then(function(r) {
				if (!r || !r.success) return;
				if (Notification.permission === 'denied') return;
				var needPrompt = Notification.permission === 'default' || (Notification.permission === 'granted' && !r.subscribed);
				if (!needPrompt) return;
				$(modalEl).modal('show');
			}).catch(function(){});
			function hideAndRemember() {
				$(modalEl).modal('hide');
				sessionStorage.setItem('pushnotify_prompt_shown', '1');
			}
			if (laterBtn) laterBtn.addEventListener('click', hideAndRemember);
			modalEl.addEventListener('hidden.bs.modal', hideAndRemember);
			function sendToken(token) {
				if (!token) return;
				var fd = new FormData();
				fd.append(window.PUSHNOTIFY_TOKEN_NAME, window.PUSHNOTIFY_TOKEN_VALUE);
				fd.append('token', token);
				fd.append('device_type', /Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent) ? 'android' : 'desktop');
				fd.append('browser', navigator.userAgent.indexOf('Chrome') >= 0 ? 'chrome' : (navigator.userAgent.indexOf('Firefox') >= 0 ? 'firefox' : (navigator.userAgent.indexOf('Edg') >= 0 ? 'edge' : '')));
				fetch(base + sep + 'task=display.subscribe&format=json', { method: 'POST', body: fd, credentials: 'same-origin' }).catch(function(){});
			}
			function loadFirebaseAndSubscribe(cb) {
				if (window.firebase && window.firebase.messaging) {
					try {
						var a = window.firebase.app();
						if (!a || !a.name) window.firebase.initializeApp(window.FIREBASE_CONFIG);
					} catch (e) { window.firebase.initializeApp(window.FIREBASE_CONFIG); }
					navigator.serviceWorker.ready.then(function() { return navigator.serviceWorker.getRegistration('/'); }).then(function(reg) {
						if (!reg) return navigator.serviceWorker.register(window.PUSHNOTIFY_SW_URL, { scope: '/' });
						return reg;
					}).then(function(reg) {
						var app = window.firebase.app();
						return app.messaging().getToken({ vapidKey: window.FIREBASE_VAPID_KEY || undefined, serviceWorkerRegistration: reg });
					}).then(cb).catch(function(){});
					return;
				}
				var s1 = document.createElement('script');
				s1.src = 'https://www.gstatic.com/firebasejs/10.7.1/firebase-app-compat.js';
				s1.onload = function() {
					var s2 = document.createElement('script');
					s2.src = 'https://www.gstatic.com/firebasejs/10.7.1/firebase-messaging-compat.js';
					s2.onload = function() {
						try { var a = window.firebase.app(); if (!a || !a.name) window.firebase.initializeApp(window.FIREBASE_CONFIG); } catch (e) { window.firebase.initializeApp(window.FIREBASE_CONFIG); }
						navigator.serviceWorker.ready.then(function() { return navigator.serviceWorker.getRegistration('/'); }).then(function(reg) {
							if (!reg) return navigator.serviceWorker.register(window.PUSHNOTIFY_SW_URL, { scope: '/' });
							return reg;
						}).then(function(reg) {
							var app = window.firebase.app();
							return app.messaging().getToken({ vapidKey: window.FIREBASE_VAPID_KEY || undefined, serviceWorkerRegistration: reg });
						}).then(cb).catch(function(){});
					};
					document.head.appendChild(s2);
				};
				document.head.appendChild(s1);
			}
			if (subscribeBtn) subscribeBtn.addEventListener('click', function() {
				subscribeBtn.disabled = true;
				Notification.requestPermission().then(function(perm) {
					if (perm === 'granted') {
						loadFirebaseAndSubscribe(function(token) {
							if (token) sendToken(token);
							hideAndRemember();
						});
					} else {
						hideAndRemember();
					}
					subscribeBtn.disabled = false;
				});
			});
		})();
	</script>
	<script>
		(function() {
			if (!window.PUSHNOTIFY_GLOBAL || !window.PUSHNOTIFY_BASE || !('Notification' in window) || Notification.permission !== 'granted') return;
			function pushnotifySendToken(token) {
				if (!token) return;
				var base = window.PUSHNOTIFY_BASE;
				var sep = base.indexOf('?') === -1 ? '?' : '&';
				var fd = new FormData();
				fd.append(window.PUSHNOTIFY_TOKEN_NAME, window.PUSHNOTIFY_TOKEN_VALUE);
				fd.append('token', token);
				fd.append('device_type', /Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent) ? 'android' : 'desktop');
				fd.append('browser', navigator.userAgent.indexOf('Chrome') >= 0 ? 'chrome' : (navigator.userAgent.indexOf('Firefox') >= 0 ? 'firefox' : (navigator.userAgent.indexOf('Edg') >= 0 ? 'edge' : '')));
				fetch(base + sep + 'task=display.subscribe&format=json', { method: 'POST', body: fd, credentials: 'same-origin' }).catch(function(){});
			}
			function pushnotifyRefresh() {
				if (!window.firebase || !window.FIREBASE_CONFIG) {
					var load = function(cb) {
						if (window.firebase && window.firebase.messaging) return cb();
						var s1 = document.createElement('script');
						s1.src = 'https://www.gstatic.com/firebasejs/10.7.1/firebase-app-compat.js';
						s1.onload = function() {
							var s2 = document.createElement('script');
							s2.src = 'https://www.gstatic.com/firebasejs/10.7.1/firebase-messaging-compat.js';
							s2.onload = function() {
								try {
									var a = window.firebase.app();
									if (!a || !a.name) window.firebase.initializeApp(window.FIREBASE_CONFIG);
								} catch (e) {
									window.firebase.initializeApp(window.FIREBASE_CONFIG);
								}
								cb();
							};
							document.head.appendChild(s2);
						};
						document.head.appendChild(s1);
					};
					load(function() {
						navigator.serviceWorker.ready.then(function() { return navigator.serviceWorker.getRegistration('/'); }).then(function(reg) {
							if (!reg) return navigator.serviceWorker.register(window.PUSHNOTIFY_SW_URL, { scope: '/' });
							return reg;
						}).then(function(reg) {
							var app;
							try { app = window.firebase.app(); } catch (e) { app = window.firebase.initializeApp(window.FIREBASE_CONFIG); }
							return app.messaging().getToken({
								vapidKey: window.FIREBASE_VAPID_KEY || undefined,
								serviceWorkerRegistration: reg
							});
						}).then(pushnotifySendToken).catch(function(){});
					});
					return;
				}
				navigator.serviceWorker.ready.then(function() { return navigator.serviceWorker.getRegistration('/'); }).then(function(reg) {
					if (!reg) return navigator.serviceWorker.register(window.PUSHNOTIFY_SW_URL, { scope: '/' });
					return reg;
				}).then(function(reg) {
					var app;
					try { app = window.firebase.app(); } catch (e) { app = window.firebase.initializeApp(window.FIREBASE_CONFIG); }
					return app.messaging().getToken({
						vapidKey: window.FIREBASE_VAPID_KEY || undefined,
						serviceWorkerRegistration: reg
					});
				}).then(pushnotifySendToken).catch(function(){});
			}
			document.addEventListener('visibilitychange', function() {
				if (document.visibilityState === 'visible') pushnotifyRefresh();
			});
			setInterval(pushnotifyRefresh, 25 * 60 * 1000);
			setTimeout(pushnotifyRefresh, 3000);
		})();
	</script>
	<?php endif; ?>
	<script>
		if ('serviceWorker' in navigator) {
			window.addEventListener('load', function () {
				var u = '<?php echo rtrim(Uri::root(), '/') . '/firebase-messaging-sw.js'; ?>';
				navigator.serviceWorker.register(u, { scope: '/' }).catch(function () {});
			});
		}
		(function(){
			function formatTimeUtc(el) {
				var iso = el && el.getAttribute('data-time-utc');
				if (!iso) return;
				try {
					var d = new Date(iso);
					if (!isNaN(d.getTime())) el.textContent = d.toLocaleString(undefined, { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
				} catch (e) {}
			}
			document.querySelectorAll('.lk-time-utc[data-time-utc]').forEach(formatTimeUtc);
		})();
	</script>
	<script>
		(function() {
			var mobileHeader = document.getElementById('header-mobile');
			var toggle = document.getElementById('header-mobile-toggle');
			var panel = document.getElementById('header-mobile-panel');
			var overlay = document.getElementById('header-mobile-overlay');
			var closeBtn = document.getElementById('header-mobile-close');
			if (!mobileHeader || !panel) return;
			function openMenu() {
				mobileHeader.classList.add('menu-open');
				panel.setAttribute('aria-hidden', 'false');
				if (overlay) overlay.setAttribute('aria-hidden', 'false');
				if (toggle) toggle.setAttribute('aria-expanded', 'true');
			}
			function closeMenu() {
				mobileHeader.classList.remove('menu-open');
				panel.setAttribute('aria-hidden', 'true');
				if (overlay) overlay.setAttribute('aria-hidden', 'true');
				if (toggle) toggle.setAttribute('aria-expanded', 'false');
				panel.querySelectorAll('.nav-item.parent.is-open').forEach(function(li) {
					li.classList.remove('is-open');
					var btn = li.querySelector('.mod-menu__toggle-sub');
					if (btn) btn.setAttribute('aria-expanded', 'false');
				});
			}
			if (toggle) toggle.addEventListener('click', function(e) { e.preventDefault(); e.stopPropagation(); mobileHeader.classList.contains('menu-open') ? closeMenu() : openMenu(); });
			if (closeBtn) closeBtn.addEventListener('click', function(e) { e.preventDefault(); e.stopPropagation(); closeMenu(); });
			if (overlay) overlay.addEventListener('click', function(e) { e.preventDefault(); closeMenu(); });
			panel.querySelectorAll('.mod-menu__toggle-sub').forEach(function(btn) {
				btn.addEventListener('click', function(e) {
					e.preventDefault();
					e.stopPropagation();
					var li = btn.closest('li.nav-item.parent');
					if (!li) return;
					var open = li.classList.toggle('is-open');
					btn.setAttribute('aria-expanded', open ? 'true' : 'false');
				});
			});
			panel.querySelectorAll('.nav-item a').forEach(function(a) {
				a.addEventListener('click', closeMenu);
			});
		})();
	</script>
	<?php
	$quickAuthGuest = $app->getIdentity()->guest;
	if ($quickAuthGuest) :
		$quickAuthToken = Session::getFormToken();
		$quickAuthAjaxUrl = Route::_('index.php?option=com_ajax&plugin=Quickauth&format=json', false);
	?>
	<div id="quick-auth-modal" class="quick-auth-modal" role="dialog" aria-modal="true" aria-labelledby="quick-auth-title" style="display:none;">
		<div class="quick-auth-modal__backdrop"></div>
		<div class="quick-auth-modal__box">
			<button type="button" class="quick-auth-modal__close" aria-label="Закрыть">&times;</button>
			<h2 id="quick-auth-title" class="quick-auth-modal__title">Записаться к мастеру</h2>
			<div class="quick-auth-modal__tab quick-auth-modal__tab--reg" id="quick-auth-tab-reg">
				<p class="quick-auth-modal__hint">Быстрая регистрация</p>
				<form id="quick-auth-form-reg" class="quick-auth-form">
					<input type="hidden" name="<?php echo $quickAuthToken; ?>" value="1">
					<input type="hidden" name="action" value="register">
					<input type="hidden" name="return" id="quick-auth-return-reg" value="">
					<div class="quick-auth-field">
						<label for="quick-auth-name">Имя</label>
						<input type="text" id="quick-auth-name" name="jform[name]" required>
					</div>
					<div class="quick-auth-field">
						<label for="quick-auth-phone">Номер телефона</label>
						<input type="tel" id="quick-auth-phone" class="js-phone-mask" name="jform[profile][phone]" placeholder="+7 (___) ___-__-__">
					</div>
					<div class="quick-auth-field">
						<label for="quick-auth-email">Email *</label>
						<input type="email" id="quick-auth-email" name="jform[email1]" required>
						<span class="quick-auth-field__hint">* для восстановления доступа к вашему профилю</span>
					</div>
					<div class="quick-auth-field">
						<label for="quick-auth-pass1">Пароль</label>
						<input type="password" id="quick-auth-pass1" name="jform[password1]" required>
					</div>
					<div class="quick-auth-field">
						<label for="quick-auth-pass2">Пароль ещё раз</label>
						<input type="password" id="quick-auth-pass2" name="jform[password2]" required>
					</div>
					<input type="hidden" name="jform[username]" id="quick-auth-username" value="">
					<input type="hidden" name="jform[registration_type]" value="client">
					<div class="quick-auth-field quick-auth-msg" id="quick-auth-msg-reg"></div>
					<button type="submit" class="btn btn__time-zapis">Зарегистрироваться и записаться</button>
				</form>
				<p class="quick-auth-modal__switch"><a href="#" id="quick-auth-show-login">У меня уже есть аккаунт</a></p>
			</div>
			<div class="quick-auth-modal__tab quick-auth-modal__tab--login" id="quick-auth-tab-login" style="display:none;">
				<p class="quick-auth-modal__hint">Вход</p>
				<form id="quick-auth-form-login" class="quick-auth-form">
					<input type="hidden" name="<?php echo $quickAuthToken; ?>" value="1">
					<input type="hidden" name="action" value="login">
					<input type="hidden" name="return" id="quick-auth-return-login" value="">
					<div class="quick-auth-field">
						<label for="quick-auth-login-username">Email или логин</label>
						<input type="text" id="quick-auth-login-username" name="username" required>
					</div>
					<div class="quick-auth-field">
						<label for="quick-auth-login-password">Пароль</label>
						<input type="password" id="quick-auth-login-password" name="password" required>
					</div>
					<div class="quick-auth-field quick-auth-msg" id="quick-auth-msg-login"></div>
					<button type="submit" class="btn btn__time-zapis">Войти и перейти к записи</button>
				</form>
				<p class="quick-auth-modal__switch"><a href="#" id="quick-auth-show-reg">Зарегистрироваться</a></p>
			</div>
		</div>
	</div>
	<script>
	(function() {
		var modal = document.getElementById('quick-auth-modal');
		var tabReg = document.getElementById('quick-auth-tab-reg');
		var tabLogin = document.getElementById('quick-auth-tab-login');
		var formReg = document.getElementById('quick-auth-form-reg');
		var formLogin = document.getElementById('quick-auth-form-login');
		var returnReg = document.getElementById('quick-auth-return-reg');
		var returnLogin = document.getElementById('quick-auth-return-login');
		var msgReg = document.getElementById('quick-auth-msg-reg');
		var msgLogin = document.getElementById('quick-auth-msg-login');
		var titleEl = document.getElementById('quick-auth-title');
		var ajaxUrl = <?php echo json_encode($quickAuthAjaxUrl); ?>;
		var currentCallback = null;
		var defaultTitle = 'Записаться к мастеру';

		function showModal(returnUrl, options) {
			options = options || {};
			returnReg.value = returnUrl || '';
			returnLogin.value = returnUrl || '';
			msgReg.textContent = '';
			msgLogin.textContent = '';
			tabReg.style.display = '';
			tabLogin.style.display = 'none';
			modal.style.display = '';
			currentCallback = options.callback || null;
			titleEl.textContent = options.title || defaultTitle;
		}
		function hideModal() {
			modal.style.display = 'none';
			currentCallback = null;
			titleEl.textContent = defaultTitle;
		}

		window.QuickAuth = {
			show: showModal,
			hide: hideModal
		};
		document.querySelectorAll('.btn__time-zapis[data-quick-auth-return]').forEach(function(btn) {
			btn.addEventListener('click', function(e) {
				var url = btn.getAttribute('data-quick-auth-return');
				if (!url) return;
				url = url.replace(/&amp;/g, '&');
				e.preventDefault();
				showModal(url);
			});
		});
		if (modal) {
			modal.querySelector('.quick-auth-modal__backdrop').addEventListener('click', hideModal);
			modal.querySelector('.quick-auth-modal__close').addEventListener('click', hideModal);
			document.getElementById('quick-auth-show-login').addEventListener('click', function(e) {
				e.preventDefault();
				tabReg.style.display = 'none';
				tabLogin.style.display = '';
				msgLogin.textContent = '';
			});
			document.getElementById('quick-auth-show-reg').addEventListener('click', function(e) {
				e.preventDefault();
				tabLogin.style.display = 'none';
				tabReg.style.display = '';
				msgReg.textContent = '';
			});
		}
		document.getElementById('quick-auth-email').addEventListener('input', function() {
			document.getElementById('quick-auth-username').value = this.value.trim();
		});
		var phoneInput = document.getElementById('quick-auth-phone');
		if (phoneInput) {
			function formatPhone(val) {
				var digits = val.replace(/\D/g, '');
				if (digits.charAt(0) === '8') digits = '7' + digits.slice(1);
				if (digits.charAt(0) !== '7') digits = '7' + digits;
				digits = digits.slice(0, 11);
				if (digits.length <= 1) return digits ? '+' + digits : '';
				var s = '+7';
				if (digits.length > 1) s += ' (' + digits.slice(1, 4);
				if (digits.length >= 4) s += ') ' + digits.slice(4, 7);
				if (digits.length >= 7) s += '-' + digits.slice(7, 9);
				if (digits.length >= 9) s += '-' + digits.slice(9, 11);
				return s;
			}
			phoneInput.addEventListener('keydown', function(e) {
				if (e.key !== 'Backspace') return;
				var pos = this.selectionStart, val = this.value;
				if (pos <= 0) return;
				var prev = val.charAt(pos - 1);
				if (prev >= '0' && prev <= '9') return;
				e.preventDefault();
				var digits = val.replace(/\D/g, '');
				if (digits.length <= 1) { this.value = ''; return; }
				this.value = formatPhone(digits.slice(0, -1));
				this.setSelectionRange(this.value.length, this.value.length);
			});
			phoneInput.addEventListener('input', function() { this.value = formatPhone(this.value); });
			phoneInput.addEventListener('focus', function() { if (this.value === '') this.value = '+7'; });
			phoneInput.addEventListener('blur', function() { if (this.value === '+7') this.value = ''; });
		}
		function submitForm(form, msgEl) {
			msgEl.textContent = '';
			var fd = new FormData(form);
			fd.append('format', 'json');
			var btn = form.querySelector('button[type="submit"]');
			var origText = btn ? btn.textContent : '';
			if (btn) { btn.disabled = true; btn.textContent = '...'; }
			fetch(ajaxUrl, { method: 'POST', body: fd, credentials: 'same-origin' })
				.then(function(r) { return r.json(); })
				.then(function(data) {
					var res = (data && data.data) ? data.data : data;
					if (res && res.success) {
						var cb = currentCallback;
						hideModal();
						if (cb && typeof cb === 'function') {
							cb(res);
							return;
						}
						if (res.redirect) {
							window.location.href = res.redirect;
							return;
						}
					}
					msgEl.textContent = (res && res.message) ? res.message : 'Ошибка';
					if (btn) { btn.disabled = false; btn.textContent = origText; }
				})
				.catch(function() {
					msgEl.textContent = 'Ошибка соединения';
					if (btn) { btn.disabled = false; btn.textContent = origText; }
				});
		}
		formReg.addEventListener('submit', function(e) {
			e.preventDefault();
			document.getElementById('quick-auth-username').value = document.getElementById('quick-auth-email').value.trim();
			submitForm(formReg, msgReg);
		});
		formLogin.addEventListener('submit', function(e) {
			e.preventDefault();
			submitForm(formLogin, msgLogin);
		});
	})();
	</script>
	<?php endif; ?>
</body>
</html>
